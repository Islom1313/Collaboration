<?php

use App\Http\Controllers\IndexController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [IndexController::class, 'index'] )->name('index');
Route::get('/category/{id}', [IndexController::class, 'category'] )->name('category');

Route::get('lesson/{id}/{video_id?}',[IndexController::class, 'lesson'])->name('lessons');
Route::post('videoComplated',[IndexController::class, 'videoComplated'])->name('videoComplated');
Route::get('test/{id}/',[IndexController::class, 'test'])->name('test');
Route::post('submit/test/',[App\Http\Controllers\TestController::class, 'testSubmit'])->name('testSubmit');
Route::post('submit/resetTest/',[App\Http\Controllers\TestController::class, 'resetTest'])->name('resetTest');
Route::post('submit/getSertificate/',[App\Http\Controllers\TestController::class, 'getSertificate'])->name('getSertificate');


Auth::routes();
Route::group(['prefix' => 'admin', 'middleware'=>'auth'], function () {
    Route::get('/', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
    Route::resource('users', App\Http\Controllers\UserController::class);
    Route::resource('categories', App\Http\Controllers\CategoryController::class);
    Route::resource('themes', App\Http\Controllers\ThemeController::class);
    Route::resource('allVideos', App\Http\Controllers\VideoController::class);
    Route::resource('carts', App\Http\Controllers\CartController::class);
    Route::resource('tests', App\Http\Controllers\TestController::class);
    Route::resource('variants', App\Http\Controllers\VariantController::class);
});

Route::get('cart/',[App\Http\Controllers\CartController::class, 'getCart'])->name('getCart');
Route::get('cart/payment',[App\Http\Controllers\CartController::class, 'Cartpayment'])->name('Cartpayment');
Route::get('cancel-payment', [App\Http\Controllers\CartController::class, 'paymentCancel'])->name('cancel.payment');
Route::get('payment-success', [App\Http\Controllers\CartController::class, 'paymentSuccess'])->name('success.payment');
Route::post('enterKey', [App\Http\Controllers\CartController::class, 'enterKey'])->name('enterKey');


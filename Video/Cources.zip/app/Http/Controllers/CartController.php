<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateCartRequest;
use App\Http\Requests\UpdateCartRequest;
use App\Repositories\CartRepository;
use App\Http\Controllers\AppBaseController;
use App\Models\Cart;
use App\Models\Category;
use App\Models\Getmailpassword;
use App\Models\Theme;
use App\Models\User;
use Illuminate\Support\Facades\Http;
use Illuminate\Http\Request;
use Flash;
use Response;
use Illuminate\Support\Str;
use Srmklive\PayPal\Services\PayPal as PayPalClient;
use App\Models\Transaction;
use App\Mail\SendMailable;
use Illuminate\Support\Facades\Mail;
class CartController extends AppBaseController
{
    /** @var  CartRepository */
    private $cartRepository;

    public function __construct(CartRepository $cartRepo)
    {
        $this->cartRepository = $cartRepo;
    }

    /**
     * Display a listing of the Cart.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function Cartpayment()
    {
        $theme_id = request()->id;
        $cart_id = request()->cart;
        if($theme_id!=null && $cart_id!=null){
             $theme = Theme::find($theme_id);
            
             $provider = new PayPalClient;
             $provider->setApiCredentials(config('paypal'));
             $token = $provider->getAccessToken();
             $newTz = new Transaction();
             $newTz->user_id = auth()->user()->id;
             $newTz->product_id = $theme->id;
             $newTz->uuid = (string) Str::uuid();
             $newTz->save();
          
             $data = array(
              'intent' => 'AUTHORIZE',
              'application_context' =>
                  array(
                      'return_url' => route('success.payment',['transaction_uuid'=>$newTz->uuid]),
                      'cancel_url' => route('cancel.payment',['transaction_uuid'=>$newTz->uuid])
                  ),
              'purchase_units' =>
                  array(
                      0 =>
                          array(
                              'amount' =>
                                  array(
                                      'currency_code' => 'GBP',
                                      'value' => $theme->sale_price != 0 ? $theme->sale_price : $theme->price
                                  )
                          )
                  )
          );
            
             $response = Http::withHeaders([
              'Content-Type' => 'application/json',
              'Authorization' => 'Bearer '.$token['access_token']
          ])->
            post(
               'https://api-m.sandbox.paypal.com/v2/checkout/orders', $data);
             
               if($response->json()['id']!=null){
                 $ans = $response->json();
                  $newTz->response_id = $ans['id'];
                  //dd($response->json());
                //   dd($ans['links'][3]['href']);
                  $newTz->save();
                 
                  Cart::where('id', $cart_id)->where('user_id', auth()->user()->id)->delete();
                  return redirect()->to($ans['links'][1]['href']);
              }
           
             
            
           // $theme = Theme::find($theme_id);
           
            //$theme->users()->attach(auth()->user()->id);
            
            //return redirect()->route('lessons', ['id'=>$theme_id]);
        }
        return redirect()->back();
    }
    public function paymentCancel()
    {
       $transaction = Transaction::where('uuid', request()->transaction_uuid)->first();
      
       if($transaction){
         $transaction->delete();
       }
       return redirect()->route('getCart')->with('status','Transaction canceled');
    }
  
    public function paymentSuccess()
    {
      $transaction = Transaction::where('uuid', request()->transaction_uuid)->first();
     
      if($transaction){
       
     
        $provider = new PayPalClient;
        $provider->setApiCredentials(config('paypal'));
        $token = $provider->getAccessToken();
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer '.$token['access_token']
        ])->
        get(
            'https://api.sandbox.paypal.com/v2/checkout/orders/'.$transaction->response_id);
        
        

            $data = array(
                'id' => $response->json()['id'],
                
            );
            $response_sec = Http::withHeaders([
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer '.$token['access_token']
                
            ])->
              post(
                $response->json()['links'][2]['href'], $data);

                // $data_third = array(
                //     'id' => $response->json()['id'],
                    
                // );
                // $response__third = Http::withHeaders([
                //     'Content-Type' => 'application/json',
                //     'Authorization' => 'Bearer '.$token['access_token']
                    
                // ])->
                //   post(
                //     'https://api-m.sandbox.paypal.com/v2/checkout/orders/'.$response->json()['id'].'/capture', $data_third);
                //     dd($response_sec->json(), $response__third->json());
        if($response_sec->json()['status']=='COMPLETED'){
           
            $pass = Getmailpassword::where('user_id',auth()->user()->id)->where('theme_id',$transaction->product_id)->first();
            if(!$pass){
              $generated_number = mt_rand();
              $pass = new Getmailpassword();
              $pass->user_id = auth()->user()->id;
              $pass->theme_id =$transaction->product_id;
              $pass->rand = $generated_number;
              $pass->save();
                Mail::to(auth()->user()->email)->send(new SendMailable($generated_number));
            }
            return redirect()->route('lessons',['id'=>$transaction->product_id]);
           
        }else{
         
          return redirect()->route('getCart')->with('status','Transaction not completed');
        }
      }
     
    }
    public function enterKey(Request $request){
      $pass = Getmailpassword::where('user_id',auth()->user()->id)->where('theme_id',$request->theme_id)->first();
      if($pass){
        if((int)$pass->rand == $request->password){
          $pass->status = 1;
          $pass->save();
          $theme = Theme::find($request->theme_id);
          $theme->users()->attach(auth()->user()->id);
          
        }
      }
      return redirect()->back()->with('status', 'key proved');
    }
    public function getCart()
    {
       
        $them_id = request()->id;
        if($them_id!=null){
            $cart = Cart::where('user_id', auth()->user()->id)->where('theme_id', $them_id)->first();
            $theme = Theme::find($them_id);
            
            if(!$theme->users->where('id',auth()->user()->id)->first() && !$cart ){
                $cart = new Cart();
                $cart->user_id = auth()->user()->id;
                $cart->theme_id = $them_id;
                $cart->save();
            }
        }
        return view('pages/cart',[
            'categories'=>Category::all(),
            'carts'=>Cart::where('user_id', auth()->user()->id)->get(),
        ]);
    }
    public function index(Request $request)
    {
        if( auth()->user()->role!=1){
            return redirect(route('home')); 
        }
        $carts = $this->cartRepository->all();

        return view('carts.index')
            ->with('carts', $carts);
    }

    /**
     * Show the form for creating a new Cart.
     *
     * @return Response
     */
    public function create()
    {
        if( auth()->user()->role!=1){
            return redirect(route('home')); 
        }
        return view('carts.create');
    }

    /**
     * Store a newly created Cart in storage.
     *
     * @param CreateCartRequest $request
     *
     * @return Response
     */
    public function store(CreateCartRequest $request)
    {
        if( auth()->user()->role!=1){
            return redirect(route('home')); 
        }
        $input = $request->all();

        $cart = $this->cartRepository->create($input);

        Flash::success('Cart saved successfully.');

        return redirect(route('carts.index'));
    }

    /**
     * Display the specified Cart.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        if( auth()->user()->role!=1){
            return redirect(route('home')); 
        }
        $cart = $this->cartRepository->find($id);

        if (empty($cart)) {
            Flash::error('Cart not found');

            return redirect(route('carts.index'));
        }

        return view('carts.show')->with('cart', $cart);
    }

    /**
     * Show the form for editing the specified Cart.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        if( auth()->user()->role!=1){
            return redirect(route('home')); 
        }
        $cart = $this->cartRepository->find($id);

        if (empty($cart)) {
            Flash::error('Cart not found');

            return redirect(route('carts.index'));
        }

        return view('carts.edit')->with('cart', $cart);
    }

    /**
     * Update the specified Cart in storage.
     *
     * @param int $id
     * @param UpdateCartRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateCartRequest $request)
    {
        if( auth()->user()->role!=1){
            return redirect(route('home')); 
        }
        $cart = $this->cartRepository->find($id);

        if (empty($cart)) {
            Flash::error('Cart not found');

            return redirect(route('carts.index'));
        }

        $cart = $this->cartRepository->update($request->all(), $id);

        Flash::success('Cart updated successfully.');

        return redirect(route('carts.index'));
    }

    /**
     * Remove the specified Cart from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {

        $cart = $this->cartRepository->find($id);
        
        if (empty($cart)) {
            Flash::error('Cart not found');

            return redirect(route('carts.index'));
        }

        $this->cartRepository->delete($id);

        Flash::success('Cart deleted successfully.');

        return redirect()->route('getCart');
    }
}

<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateTestRequest;
use App\Http\Requests\UpdateTestRequest;
use App\Repositories\TestRepository;
use App\Http\Controllers\AppBaseController;
use App\Models\Test;
use App\Models\TestResult;
use App\Models\Theme;
use App\Models\Variant;
use Barryvdh\DomPDF\Facade as PDF;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Flash;
use Response;
use Illuminate\Support\Str;

class TestController extends AppBaseController
{
    /** @var  TestRepository */
    private $testRepository;

    public function __construct(TestRepository $testRepo)
    {
        $this->testRepository = $testRepo;
    }

    /**
     * Display a listing of the Test.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function testSubmit(Request $request)
    {
        // dd();
        $input  =$request->all();
        foreach($input as $k=>$in){
            if($k!='_token'){
                $test = (string)Str::of($k)->replace('q-','');
                $testresult = TestResult::where('test_id', $test)->where('user_id', auth()->user()->id)->first();
                if($testresult){
                    $testresult->variant_id = $in;
                    $variant = Variant::find($in);
                    $testresult->status = $variant? $variant->status : 0;
                    $testresult->save(); 
                }else{
                    $testresult = new TestResult();
                    $testresult->test_id = $test;
                    $testresult->variant_id = $in;
                    $variant = Variant::find($in);
                    $testresult->status = $variant? $variant->status : 0;
                    $testresult->user_id = auth()->user()->id;
                    $testresult->save();
                }
            }
        }
        
        return redirect()->back(); 
    }
    public function resetTest(Request $request)
    {
        $theme = Theme::find($request->theme_id);
        if($theme){
            $question = $theme->questions;
            if(count($question)>0){
                foreach ($question as $q) {
                    TestResult::where('test_id', $q->id)->where('user_id', auth()->user()->id)->delete();
                }
            }
        }
        
        return redirect()->back();
    }
    public function getSertificate(Request $request)
    {
        $theme = Theme::find($request->theme_id);

        $data = [
            'score'=>$request->score,
            'name'=>auth()->user()->name,
            'theme'=>$theme? $theme->name : '',
            'time' => Carbon::now()->format('d.m.Y')
        ];
        $pdf = PDF::loadView('pdf.pdf', $data)->setPaper('a4', 'landscape')->stream();   
        return $pdf;
        return redirect()->back();
    }
    public function index(Request $request)
    {
        if(auth()->user()->role==1){
            $tests =Test::orderby('created_at', 'desc')->get();
        }else{

            $tests =Test::where('user_id', auth()->user()->id)->orderby('created_at', 'desc')->get();
        }
       
        return view('tests.index',[
            'tests'=>$tests
        ]);
    }

    /**
     * Show the form for creating a new Test.
     *
     * @return Response
     */
    public function create()
    {
        if(auth()->user()->role==1){
            $themes = Theme::all();
        }else{
            $themes = Theme::where('user_id', auth()->user()->id)->get();
        }
        return view('tests.create',[
            'themes'=>$themes
        ]);
    }

    /**
     * Store a newly created Test in storage.
     *
     * @param CreateTestRequest $request
     *
     * @return Response
     */
    public function store(CreateTestRequest $request)
    {
        // $input = $request->all();

        // $test = $this->testRepository->create($input);
        $test = new Test();
        $test->question = $request->question;
        $test->theme_id = $request->theme_id;
        $test->user_id = auth()->user()->id;
        $test->orders = $request->orders;
        if($test->save()){
            Flash::success('Test saved successfully.');

        }else{
            Flash::success('Test save Error.');

        }

        return redirect(route('tests.index'));
    }

    /**
     * Display the specified Test.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $test = $this->testRepository->find($id);

        if (empty($test)) {
            Flash::error('Test not found');

            return redirect(route('tests.index'));
        }

        return view('tests.show')->with('test', $test);
    }

    /**
     * Show the form for editing the specified Test.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $test = $this->testRepository->find($id);

        if (empty($test)) {
            Flash::error('Test not found');

            return redirect(route('tests.index'));
        }
        if(auth()->user()->role==1){
            $themes = Theme::all();
        }else{
            $themes = Theme::where('user_id', auth()->user()->id)->get();
        }
        return view('tests.edit')->with(['test'=> $test, 'themes'=>$themes]);
    }

    /**
     * Update the specified Test in storage.
     *
     * @param int $id
     * @param UpdateTestRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateTestRequest $request)
    {
        $test = $this->testRepository->find($id);

        if (empty($test)) {
            Flash::error('Test not found');

            return redirect(route('tests.index'));
        }

        $test = $this->testRepository->update($request->all(), $id);

        Flash::success('Test updated successfully.');

        return redirect(route('tests.index'));
    }

    /**
     * Remove the specified Test from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        $test = $this->testRepository->find($id);

        if (empty($test)) {
            Flash::error('Test not found');

            return redirect(route('tests.index'));
        }

        $this->testRepository->delete($id);

        Flash::success('Test deleted successfully.');

        return redirect(route('tests.index'));
    }
}

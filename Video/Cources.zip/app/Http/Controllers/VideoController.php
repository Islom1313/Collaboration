<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateVideoRequest;
use App\Http\Requests\UpdateVideoRequest;
use App\Repositories\VideoRepository;
use App\Http\Controllers\AppBaseController;
use App\Models\Theme;
use App\Models\Video;
use Illuminate\Http\Request;
use Flash;
use Response;

class VideoController extends AppBaseController
{
    /** @var  VideoRepository */
    private $videoRepository;

    public function __construct(VideoRepository $videoRepo)
    {
        $this->videoRepository = $videoRepo;
    }

    /**
     * Display a listing of the Video.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        if(auth()->user()->role == 1){
            $videos = Video::orderby('created_at','desc')->get();
        }else{

            $videos = Video::where('user_id',auth()->user()->id)->orderby('created_at','desc')->get();
        }

        return view('videos.index')
            ->with('videos', $videos);
    }

    /**
     * Show the form for creating a new Video.
     *
     * @return Response
     */
    public function create()
    {
        if(auth()->user()->role == 1){
            $themes  = Theme::orderby('created_at','desc')->get();
        }else{
            $themes  = Theme::where('user_id',auth()->user()->id)->orderby('created_at','desc')->get();
        }
        return view('videos.create',[
            'themes'=>$themes
        ]);
    }

    /**
     * Store a newly created Video in storage.
     *
     * @param CreateVideoRequest $request
     *
     * @return Response
     */
    public function store(CreateVideoRequest $request)
    {
        // dd($request->all());
        if($request->hasFile('path')){
            $file = $request->file('path');
            $name = floor(time()-999999999).'.'.$file->getClientOriginalExtension();
            $file->move(public_path('upload/videos/file'), $name);
            $video = new Video();
            $video->img = '';
            $video->user_id = auth()->user()->id;
            $video->name = $request->name;
            $video->body = $request->body;
            $video->order = $request->order;
            $video->theme_id = $request->theme_id;
            $video->level = $request->level;
            $video->path = $name;
            if($video->save()){
                Flash::success('Video saved successfully.');

            }else{
                Flash::success('Video save error.');
            }
        }else{
            Flash::success('Video file not exist .');
        }
        return redirect(route('allVideos.index'));
    }

    /**
     * Display the specified Video.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $video = $this->videoRepository->find($id);

        if (empty($video)) {
            Flash::error('Video not found');

            return redirect(route('videos.index'));
        }

        return view('allVideos.show')->with('video', $video);
    }

    /**
     * Show the form for editing the specified Video.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $video = $this->videoRepository->find($id);

        if (empty($video)) {
            Flash::error('Video not found');

            return redirect(route('videos.index'));
        }

        return view('videos.edit')->with(['video'=> $video, 'themes'=>Theme::all()]);
    }

    /**
     * Update the specified Video in storage.
     *
     * @param int $id
     * @param UpdateVideoRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateVideoRequest $request)
    {
        $video = $this->videoRepository->find($id);

        if (empty($video)) {
            Flash::error('Video not found');

            return redirect(route('allVideos.index'));
        }

        if($request->hasFile('path')){
            $file = $request->file('path');
            $name = floor(time()-999999999).'.'.$file->getClientOriginalExtension();
            $file->move(public_path('upload/videos/file'), $name);
            $video->path = $name;
            
        }
        $video->img = '';
        $video->user_id = auth()->user()->id;
        $video->name = $request->name;
        $video->body = $request->body;
        $video->order = $request->order;
        $video->theme_id = $request->theme_id;
        $video->level = $request->level;
        if($video->save()){
            Flash::success('Video updated successfully.');

        }else{
            Flash::error('Video updated error.');
        }
      

        return redirect(route('allVideos.index'));
    }

    /**
     * Remove the specified Video from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        $video = $this->videoRepository->find($id);

        if (empty($video)) {
            Flash::error('Video not found');

            return redirect(route('videos.index'));
        }

        $this->videoRepository->delete($id);

        Flash::success('Video deleted successfully.');

        return redirect(route('videos.index'));
    }
}

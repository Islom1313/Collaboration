<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateVariantRequest;
use App\Http\Requests\UpdateVariantRequest;
use App\Repositories\VariantRepository;
use App\Http\Controllers\AppBaseController;
use App\Models\Test;
use Illuminate\Http\Request;
use Flash;
use Response;

class VariantController extends AppBaseController
{
    /** @var  VariantRepository */
    private $variantRepository;

    public function __construct(VariantRepository $variantRepo)
    {
        $this->variantRepository = $variantRepo;
    }

    /**
     * Display a listing of the Variant.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        return redirect(route('home'));
        $variants = $this->variantRepository->all();

        return view('variants.index')
            ->with('variants', $variants);
    }

    /**
     * Show the form for creating a new Variant.
     *
     * @return Response
     */
    public function create()
    {
        return view('variants.create',[
            'questions'=>Test::where('user_id', auth()->user()->id)->get()
        ]);
    }

    /**
     * Store a newly created Variant in storage.
     *
     * @param CreateVariantRequest $request
     *
     * @return Response
     */
    public function store(CreateVariantRequest $request)
    {
        $input = $request->all();

        $variant = $this->variantRepository->create($input);

        Flash::success('Variant saved successfully.');

        return redirect(route('tests.index'));
    }

    /**
     * Display the specified Variant.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $variant = $this->variantRepository->find($id);

        if (empty($variant)) {
            Flash::error('Variant not found');

            return redirect(route('variants.index'));
        }

        return view('variants.show')->with('variant', $variant);
    }

    /**
     * Show the form for editing the specified Variant.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $variant = $this->variantRepository->find($id);

        if (empty($variant)) {
            Flash::error('Variant not found');

            return redirect(route('variants.index'));
        }

        return view('variants.edit',[
            'questions'=>Test::where('user_id', auth()->user()->id)->get()
        ])->with('variant', $variant);
    }

    /**
     * Update the specified Variant in storage.
     *
     * @param int $id
     * @param UpdateVariantRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateVariantRequest $request)
    {
        $variant = $this->variantRepository->find($id);

        if (empty($variant)) {
            Flash::error('Variant not found');

            return redirect(route('tests.index'));
        }

        $variant = $this->variantRepository->update($request->all(), $id);

        Flash::success('Variant updated successfully.');

        return redirect(route('variants.index'));
    }

    /**
     * Remove the specified Variant from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        $variant = $this->variantRepository->find($id);

        if (empty($variant)) {
            Flash::error('Variant not found');

            return redirect(route('variants.index'));
        }

        $this->variantRepository->delete($id);

        Flash::success('Variant deleted successfully.');

        return redirect(route('variants.index'));
    }
}

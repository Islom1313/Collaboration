<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\TestResult;
use App\Models\Theme;
use App\Models\Video;
use App\Models\VideoCompleted;
use Illuminate\Http\Request;

class IndexController extends Controller
{
    public function index()
    {  
        $themes = Theme::with(['videos'=> function($q){
            $q->where('videos.free', '=', 1);
        }])->where('prim',1)->get();
    //    dd($themes[0]);
        return view('welcome',[
            'categories'=>Category::all(),
            'themes'=>$themes,
        ]);
    }
    public function videoComplated(Request $request)
    {
       
        $theme_id = $request->theme_id;
        $video_id = $request->video_id;
        $user_id = auth()->user()->id;
        $videoCompleted = VideoCompleted::where('theme_id', $theme_id)->where('video_id', $video_id)->where('user_id', $user_id)->first();
        if(!$videoCompleted){
            $videoCompleted = new VideoCompleted();
            $videoCompleted->theme_id = $theme_id;
            $videoCompleted->video_id = $video_id;
            $videoCompleted->user_id = $user_id;
            $videoCompleted->save();
        }
        return response()->json([
            'status'=>true,
        ]);

    }
    public function lesson($id, $video_id=null)
    {
        $theme = Theme::findorFail($id);
        $user = $theme->users->where('id',auth()->user()->id)->first();
        if($user!=null){
            $video = $theme->videos()->where('id', $video_id)->first(); 
        }else{
            $video = null;
        }
        if($video==null){
            $video = $theme->videos()->where('free',1)->first();
        }
        $countVideo = $theme->videos->count();
        $countSeen  = VideoCompleted::where('theme_id', $id)->where('user_id', auth()->user()->id)->count();
        if($countVideo== $countSeen && $countVideo!=0){
            $finished_video = true;
        }else{
            $finished_video = false;
        }
        return view('pages/lesson',[
            'categories'=>Category::all(),
            'theme'=>$theme,
            'video'=>$video,
            'finished_video' => $finished_video,
            'vids'=>$theme->videos()->orderby('order','asc')->select('id','name', 'theme_id')->get(),
         
        ]);
    }
    public function test($id)
    {
        $theme = Theme::findorFail($id);
        $access = $theme->users->where('id',auth()->user()->id)->first();
        if(!$access){
            return redirect()->route('index');
        }
        $questions = $theme->questions;
        $sum = 0;
        $countQuestion = count($questions);
        $countAnswers = 0;
        if($countQuestion>0){
            
            foreach ($questions as $key => $question) {
                $testResult  = TestResult::where('test_id', $question->id)->where('user_id', auth()->user()->id)->first();
                if($testResult){
                    $countAnswers ++;
                    $sum+= $testResult ->status;
                }  
                # code...
            }
        }
      
        return view('pages/test',[
            'categories'=>Category::all(),
            'theme'=>$theme,
            'countAnswers'=>$countAnswers,
            'countQuestion'=>$countQuestion,
            'sum'=>$sum,
            'finished_video' => true,
            'vids'=>$theme->videos()->orderby('order','asc')->select('id','name', 'theme_id')->get(),
            // 'video_id'=>$video_id,
        ]);
    }
    public function category($id)
    {
        $themes = Theme::where('category_id',$id)->paginate(9);
        return view('pages/category',[
            'categories'=>Category::all(),
            'themes'=>$themes,
            'name'=>Category::select('name')->where('id',$id)->first($id)
            
        ]);
    }
}

<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateUserRequest;
use App\Http\Requests\UpdateUserRequest;
use App\Repositories\UserRepository;
use App\Http\Controllers\AppBaseController;
use App\Models\User;
use Illuminate\Http\Request;
use Flash;
use Illuminate\Support\Facades\Hash;
use Response;

class UserController extends AppBaseController
{
    /** @var  UserRepository */
    private $userRepository;

    public function __construct(UserRepository $userRepo)
    {
        $this->userRepository = $userRepo;
    }

    /**
     * Display a listing of the User.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        if( auth()->user()->role!=1){
            return redirect(route('home')); 
        }
        $users = $this->userRepository->all();
      
        return view('users.index')
            ->with('users', $users);
    }

    /**
     * Show the form for creating a new User.
     *
     * @return Response
     */
    public function create()
    {
        if( auth()->user()->role!=1){
            return redirect(route('home')); 
        }
        return view('users.create');
    }

    /**
     * Store a newly created User in storage.
     *
     * @param CreateUserRequest $request
     *
     * @return Response
     */
    public function store(CreateUserRequest $request)
    {
        if( auth()->user()->role!=1){
            return redirect(route('home')); 
        }
        $input = $request->all();

        $user = $this->userRepository->create($input);

        Flash::success('User saved successfully.');

        return redirect(route('users.index'));
    }

    /**
     * Display the specified User.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        if( auth()->user()->role!=1){
            return redirect(route('home')); 
        }
        $user = $this->userRepository->find($id);

        if (empty($user)) {
            Flash::error('User not found');

            return redirect(route('users.index'));
        }
        
        return view('users.show')->with('user', $user);
    }

    /**
     * Show the form for editing the specified User.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        
        $user =User::findorFail($id);
       
        if (empty($user)) {
            Flash::error('User not found');

            return redirect(route('users.index'));
        }
        if($user->id = auth()->user()->id || auth()->user()->role==1){
            
            return view('users.edit',[
                'user'=> $user
            ]);

        }
    }

    /**
     * Update the specified User in storage.
     *
     * @param int $id
     * @param UpdateUserRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateUserRequest $request)
    {
        $user = $this->userRepository->find($id);
      
        if (empty($user)) {
            Flash::error('User not found');

            return redirect(route('users.index'));
        }
        // dd($user, $id);
        if($user->id == auth()->user()->id || auth()->user()->role==1){

            $user->name = $request->name;
            $user->email = $request->email;
            if($user->password!=null){
    
                $user->password = Hash::make($request->password);
            }
           
            $user->save();
            Flash::success('User updated successfully.');
        }else{
            Flash::error('User error');
        }
        

        return redirect(route('users.index'));
    }

    /**
     * Remove the specified User from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        $user = $this->userRepository->find($id);

        if (empty($user)) {
            Flash::error('User not found');

            return redirect(route('users.index'));
        }
        if(auth()->user()->role==1){

            $this->userRepository->delete($id);
            Flash::success('User deleted successfully.');
        }else{
            Flash::error('You are not admin.');
        }


        return redirect(route('users.index'));
    }
}

<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateThemeRequest;
use App\Http\Requests\UpdateThemeRequest;
use App\Repositories\ThemeRepository;
use App\Http\Controllers\AppBaseController;
use App\Models\Category;
use App\Models\Theme;
use Illuminate\Http\Request;
use Flash;
use Response;

class ThemeController extends AppBaseController
{
    /** @var  ThemeRepository */
    private $themeRepository;

    public function __construct(ThemeRepository $themeRepo)
    {
        $this->themeRepository = $themeRepo;
    }

    /**
     * Display a listing of the Theme.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        if(auth()->user()->role==1){
            $themes = Theme::orderby('created_at', 'desc')->get();
        }else{

            $themes = Theme::where('user_id', auth()->user()->id)->orderby('created_at', 'desc')->get();
        }
        
        return view('themes.index',['themes'=> $themes]);
            
    }

    /**
     * Show the form for creating a new Theme.
     *
     * @return Response
     */
    public function create()
    {
        return view('themes.create',[
            'categories'=>Category::all(),
        ]);
    }

    /**
     * Store a newly created Theme in storage.
     *
     * @param CreateThemeRequest $request
     *
     * @return Response
     */
    public function store(CreateThemeRequest $request)
    {
        // dd($request->all());
        if($request->hasFile('img')){
            $file = $request->file('img');
            $name = floor(time()-999999999).'.'.$file->getClientOriginalExtension();
            $file->move(public_path('upload/videos/poster/'), $name);
            $theme = new Theme();
            $theme->name = $request->name;
            $theme->body = $request->body;
            $theme->img = $name;
            $theme->undertitle = $request->undertitle;
            $theme->user_id = auth()->user()->id;
            $theme->category_id = $request->category_id;
            $theme->price = $request->price;
            $theme->sale = $request->sale;
            $theme->sale_price = $request->sale_price;
            if($theme->save()){
                Flash::success('Theme saved successfully.');

            }else{
                Flash::success('Theme save error.');
            }
        }else{
            Flash::success('Theme save error no img.');

        }
        // $theme = $this->themeRepository->create($input);


        return redirect(route('themes.index'));
    }

    /**
     * Display the specified Theme.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $theme = $this->themeRepository->find($id);

        if (empty($theme)) {
            Flash::error('Theme not found');

            return redirect(route('themes.index'));
        }

        return view('themes.show')->with('theme', $theme);
    }

    /**
     * Show the form for editing the specified Theme.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {

        $theme = $this->themeRepository->find($id);

        if (empty($theme)) {
            Flash::error('Theme not found');

            return redirect(route('themes.index'));
        }
        if($theme->user_id == auth()->user()->id || auth()->user()->role==1){

            return view('themes.edit')->with(['theme'=> $theme, 'categories'=> Category::all()]);
        }else{
            return redirect(route('themes.index'));
        }
    }

    /**
     * Update the specified Theme in storage.
     *
     * @param int $id
     * @param UpdateThemeRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateThemeRequest $request)
    {
        $theme = $this->themeRepository->find($id);

        if (empty($theme)) {
            Flash::error('Theme not found');

            return redirect(route('themes.index'));
        }
        if($request->hasFile('img')){
            $file = $request->file('img');
            $name = floor(time()-999999999).'.'.$file->getClientOriginalExtension();
            $file->move(public_path('upload/videos/poster/'), $name);
            $theme->img = $name;
            
        }
        $theme->name = $request->name;
        $theme->body = $request->body;
        $theme->undertitle = $request->undertitle;
        $theme->user_id = auth()->user()->id;
        $theme->category_id = $request->category_id;
        $theme->price = $request->price;
        $theme->sale = $request->sale;
        $theme->sale_price = $request->sale_price;
        if($theme->save()){
            Flash::success('Theme updated successfully.');

        }else{
            Flash::error('Theme updated error.');
        }

        

        return redirect(route('themes.index'));
    }

    /**
     * Remove the specified Theme from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
    public function destroy($id)
    {
        $theme = $this->themeRepository->find($id);

        if (empty($theme)) {
            Flash::error('Theme not found');

            return redirect(route('themes.index'));
        }

        $this->themeRepository->delete($id);

        Flash::success('Theme deleted successfully.');

        return redirect(route('themes.index'));
    }
}

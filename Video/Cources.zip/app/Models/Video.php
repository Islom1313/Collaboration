<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * Class Video
 * @package App\Models
 * @version April 23, 2021, 5:03 am UTC
 *
 */
class Video extends Model
{
    // use SoftDeletes;

    use HasFactory;

    public $table = 'videos';
    

    // protected $dates = ['deleted_at'];



    protected $guarded = [];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'name'=>'required',
        'order'=>'required',
        'body'=>'required',
        'path'=>'file|max:1024',
        'theme_id'=>'required',
        
        
    ];

    public function theme()
    {
        return $this->belongsTo(Theme::class);
    }
    public function access($theme_id, $video_id){
        return VideoCompleted::where('theme_id', $theme_id)->where('video_id', $video_id)->where('user_id', auth()->user()->id)->first();
    }
}

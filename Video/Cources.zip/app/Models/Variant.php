<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * Class Variant
 * @package App\Models
 * @version April 25, 2021, 1:59 pm UTC
 *
 */
class Variant extends Model
{
   

    use HasFactory;

    public $table = 'variants';
    

  



    protected $guarded = [];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'test_id'=>'required',
        'answer'=>'required',
        'status'=>'required',
    ];

    
}

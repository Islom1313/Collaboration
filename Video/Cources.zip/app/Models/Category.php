<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * Class Category
 * @package App\Models
 * @version April 23, 2021, 4:56 am UTC
 *
 */
class Category extends Model
{
    // use SoftDeletes;

    use HasFactory;

    public $table = 'categories';
    

    // protected $dates = ['deleted_at'];



    public $fillable = [
        
        'name',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        
    ];
    public function themes()
    {
        return $this->hasMany(Theme::class);
    }
    
}

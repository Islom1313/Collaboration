<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

/**
 * Class User
 * @package App\Models
 * @version April 23, 2021, 4:44 am UTC
 *
 */
class User extends Authenticatable
{
    
    use HasFactory;

    public $table = 'users';
    

   



    protected $guarded = [];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
   

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        
    ];

    public function themes()
    {
        return $this->belongsToMany(Theme::class, 'theme_user');
    }
    public function carts()
    {
        return $this->hasMany(Cart::class);
    }
}

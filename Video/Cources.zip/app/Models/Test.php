<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * Class Test
 * @package App\Models
 * @version April 25, 2021, 1:59 pm UTC
 *
 */
class Test extends Model
{
   

    use HasFactory;

    public $table = 'tests';
    

   



    protected $guarded = [];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'theme_id'=>'required',
        'question'=>'required',
        'orders'=>'required',
    ];
    public function theme()
    {
        return $this->belongsTo(Theme::class);
    }
    public function variants()
    {
        return $this->hasMany(Variant::class);
    }
    
}

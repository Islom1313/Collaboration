<?php

namespace App\Models;

use Illuminate\Contracts\Auth\Guard;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * Class Theme
 * @package App\Models
 * @version April 23, 2021, 4:58 am UTC
 *
 */
class Theme extends Model
{
    // use SoftDeletes;

    use HasFactory;

    public $table = 'themes';
    

    // protected $dates = ['deleted_at'];



    protected $guarded = [];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'name'=>'required',
        'undertitle'=>'required',
        'body'=>'required',
        'img'=>'file|max:512|dimensions:width=459,height=258',
        'category_id'=>'required',
        'price'=>'required',
        'sale'=>'required',
        'sale_price'=>'required',
    ];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }
    public function videos()
    {
        return $this->hasMany(Video::class);
    }
    public function user()
    {
        return $this->belongsTo(User::class);
    }
    public function users(){
        return $this->belongsToMany(User::class, 'theme_user');
    }
    public function questions()
    {
        return $this->hasMany(Test::class);
    }
}

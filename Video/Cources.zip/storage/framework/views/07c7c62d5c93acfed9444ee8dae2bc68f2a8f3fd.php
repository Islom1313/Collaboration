<div style="width:100%; height:625px; padding:20px; text-align:center; border: 10px solid #787878">
    <div style="width:95%; height:550px; padding:20px; text-align:center; border: 5px solid #787878">
           <span style="font-size:50px; font-weight:bold">Certificate of Completion</span>
           <br><br>
           <span style="font-size:25px"><i>This is to certify that</i></span>
           <br><br>
           <span style="font-size:30px"><b><?php echo e($name); ?></b></span><br/><br/>
           <span style="font-size:25px"><i>has completed the course</i></span> <br/><br/>
           <span style="font-size:30px"><?php echo e($theme); ?></span> <br/><br/>
           <span style="font-size:20px">with score of <b><?php echo e($score); ?>%</b></span> <br/><br/><br/><br/>
           <span style="font-size:25px"><i>dated</i></span><br>
         <?php echo e($time); ?>  id <?php echo e(rand(50005000, 90009000)); ?>

         
    </div>
    </div><?php /**PATH /var/www/resources/views/pdf/pdf.blade.php ENDPATH**/ ?>
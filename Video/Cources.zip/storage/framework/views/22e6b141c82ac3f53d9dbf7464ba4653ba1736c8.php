<div class="col-md-6">
    <label for="name">name</label>
    <input class="form-control" name="name" value="<?php echo e(isset($user)? $user->name : ''); ?>" type="text" id="name"> 
</div>
<div class="col-md-6">
    <label for="email">email</label>
    <input class="form-control" name="email" value="<?php echo e(isset($user)? $user->email : ''); ?>" type="email" id="name"> 
</div>
<div class="col-md-6">
    <label for="password">password</label>
    <input class="form-control" name="password" type="password" id="password"> 
</div>
<?php /**PATH /var/www/resources/views/users/fields.blade.php ENDPATH**/ ?>
<?php $__env->startSection('body'); ?>
  <div class="container fx">
    <?php echo $__env->make('layouts.client.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="mainSide">
      <a href="<?php echo e(route('register')); ?>" style="margin-bottom:1rem; display:block">
        <img src="<?php echo e(asset('img/banner.png')); ?>" style="width:100%">
      </a>
      <div class="mainSide__title">
        <h2><?php echo e($name? $name->name : ''); ?></h2>
      </div>
     
      <?php if(count($themes)>0): ?>
      
      
      <div class="mainSide__videos fx">
        <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="mainSide__videos-each" >
          <div  class="mainSide__videos__poster"  data-video="<?php echo e(count($theme->videos)>0? route('index').'/upload/videos/file/'.$theme->videos[0]->path : '#'); ?>"  onclick="openModal(this)">
            <img  src="<?php echo e(asset('upload/videos/poster/'.$theme->img)); ?>">
            <img src="<?php echo e(asset('img/play.svg')); ?>" width="15" class="play_button">
          </div>
          <div class="mainSide__videos__title" <?php if(auth()->check()): ?> data-url="<?php echo e(route('lessons',['id'=>$theme->id])); ?>" onclick="openurl(this)"
            
            <?php endif; ?>>
            <p><?php if($theme->prim): ?> <span>BEST SELLER</span> <?php endif; ?> <?php echo e($theme->name); ?></p>
          </div>
          <div class="mainSide__videos__author"  <?php if(auth()->check()): ?> data-url="<?php echo e(route('lessons',['id'=>$theme->id])); ?>" onclick="openurl(this)"
            
            <?php endif; ?>>
            <p>A course by <i><?php echo e($theme->user->name); ?></i></p>  
          </div>
          <div class="mainSide__videos__undertitle"  <?php if(auth()->check()): ?> data-url="<?php echo e(route('lessons',['id'=>$theme->id])); ?>" onclick="openurl(this)"
            
            <?php endif; ?> >
            <p><?php echo e($theme->undertitle); ?></p>
              
          </div>
          <div class="mainSide__videos__statistic">
            <ul>
              <li><img src="<?php echo e(asset('img/group.svg')); ?>" width="15"> <?php echo e(rand(10000, 85000)); ?> </li>
              <li><img src="<?php echo e(asset('img/like.svg')); ?>" width="15"> <?php echo e(rand(45, 100)); ?>% </li>
            </ul>
          </div>
          <div class="mainSide__videos__week " data-video="<?php echo e(count($theme->videos)>0? route('index').'/upload/videos/file/'.$theme->videos[0]->path : '#'); ?>" onclick="openModal(this)">
            <p class="fx vertical_center"><img style="margin-right: 0.5rem" src="<?php echo e(asset('img/preview.svg')); ?>" width="15">   Preview</p> 
          </div>
          <div class="mainSide__videos__discount">
            <?php echo e($theme->sale); ?>% <span>$<?php echo e($theme->price); ?> USD</span>  
          </div>
          <div class="mainSide__videos__price" <?php if(auth()->check()): ?> data-url="<?php echo e(route('index')); ?>" onclick="openCart(this,<?php echo e($theme->id); ?>)"
            
            <?php else: ?> onclick="shownotification()" <?php endif; ?>>
            <img src="<?php echo e(asset('img/cart.svg')); ?>" width="20"> $<?php echo e(number_format($theme->sale_price,2)); ?> USD
          </div>  
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <?php endif; ?>
      
     
    </div>
  </div>
  <link href="https://vjs.zencdn.net/7.11.4/video-js.css" rel="stylesheet" />
  <link href="https://unpkg.com/@videojs/themes@1/dist/forest/index.css" 
rel="stylesheet">
  <div class="modal">
    <div class="modal__centent">
      <div class="modal__body">
        <div class="close" onclick="document.querySelector('.modal').style.display='none'">✕</div>
        <video
    id="my-video"
    class="video-js vjs-theme-forest"
    controls
    preload="auto"
    width="450"
    height="264"
   
    data-setup="{}"
  >
    <source id="modalVideoSource" src="<?php echo e(asset('upload/videos/file/619162548.mp4')); ?>" type="video/mp4" />
    
    <p class="vjs-no-js">
      To view this video please enable JavaScript, and consider upgrading to a
      web browser that
      <a href="https://videojs.com/html5-video-support/" target="_blank"
        >supports HTML5 video</a
      >
    </p>
  </video>
      </div>
    </div>
  </div>
  <script src="https://vjs.zencdn.net/7.11.4/video.min.js"></script>
  <script>
    
    function shownotification(){
      document.querySelector('.notification').classList.add('active');
      setTimeout(() => {
        document.querySelector('.notification').classList.remove('active')
      }, 2000);
    }
    function openurl(e){
      let url = e.getAttribute('data-url');
      // console.log(url);
      window.open(url);
    }
    function openCart(e,id){
      let url = e.getAttribute('data-url');
      // console.log(url);
      window.open(url+'/cart/?id='+id);
    }
    function openModal(e){
      let video = e.getAttribute('data-video');
      document.getElementById('modalVideoSource').src = video;
      document.querySelector('.modal').style.display='flex';
    }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/pages/category.blade.php ENDPATH**/ ?>
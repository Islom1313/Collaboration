<div class="table-responsive">
    <table class="table" id="tests-table">
        <thead>
            <tr>
                <th>Theme</th>
                <th>Question</th>
                <th>Order</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($test->theme->name); ?></td>
                <td><b><?php echo e($test->question); ?></b>
                    <?php if(count($test->variants)>0): ?>
                    <?php
                        $count = 1;
                    ?>
                        <?php $__currentLoopData = $test->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row">

                            <p class="col-6"><?php echo e($count .' '. $variant->answer); ?></p>
                            <?php echo Form::open(['route' => ['variants.destroy', $variant->id], 'method' => 'delete']); ?>

                            <div class='btn-group'>
                                
                                <a href="<?php echo e(route('variants.edit', [$variant->id])); ?>/?id=<?php echo e($test->id); ?>" class='btn btn-default btn-xs'>
                                    <i class="far fa-edit"></i>
                                </a>
                                <?php echo Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                            </div>
                            <?php echo Form::close(); ?>

                        </div>
                        <?php
                            $count++;
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                   
                        
                    <?php endif; ?>
                    <a class="btn btn-primary float-right"
                       href="<?php echo e(route('variants.create')); ?>/?id=<?php echo e($test->id); ?>">
                        Add answers
                    </a>
                   
                
                
                </td>
                <td><?php echo e($test->orders); ?></td>
                <td width="120">
                    <?php echo Form::open(['route' => ['tests.destroy', $test->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('tests.show', [$test->id])); ?>" class='btn btn-default btn-xs'>
                            <i class="far fa-eye"></i>
                        </a>
                        <a href="<?php echo e(route('tests.edit', [$test->id])); ?>" class='btn btn-default btn-xs'>
                            <i class="far fa-edit"></i>
                        </a>
                        <?php echo Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /var/www/resources/views/tests/table.blade.php ENDPATH**/ ?>
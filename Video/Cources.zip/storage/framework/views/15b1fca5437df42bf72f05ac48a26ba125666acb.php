<!-- Created At Field -->
<div class="col-sm-12">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo e($variant->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="col-sm-12">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo e($variant->updated_at); ?></p>
</div>

<?php /**PATH /var/www/resources/views/variants/show_fields.blade.php ENDPATH**/ ?>
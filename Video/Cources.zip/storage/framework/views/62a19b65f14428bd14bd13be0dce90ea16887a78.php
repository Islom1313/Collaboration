<footer>
   <div>
    © copyright <span id="year"></span>  | Online courses for creative professionals
   </div>
</footer>
<script>
    document.getElementById("year").innerHTML = new Date().getFullYear();
</script>
<style>
    footer{
        margin-top: 25px;
        background-color: rgba(0, 0, 0, 0.603);
        text-align: center;
        color: white;
        padding: 15px 0;
    }
</style><?php /**PATH /var/www/resources/views/layouts/footer.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">

        <div class="table-responsive">
            <?php if(count($themes)>0): ?>
            <table class="table" id="themes-table">
                <thead>
                    <tr>
                        <th>name</th>
                      
                        <th>img</th>
                        <th>category</th>
                       
                        <th colspan="3">Action</th>
                    </tr>
                </thead>
                <tbody>
                   
                        
                    
                <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($theme->name); ?></td>
                       
                       
        
                        <td><img src="<?php echo e(asset('upload/videos/poster/'.$theme->img)); ?>" width="250"></td>
                        <td><?php echo e($theme->category->name); ?></td>
                       
                        <td width="120">
                            <div class='btn-group'>
                                <a href="<?php echo e(route('lessons', [$theme->id])); ?>" class='btn btn-default btn-xs'>
                                    <i class="far fa-eye"></i>
                                </a>
                               
                            </div>
                         
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php else: ?>
                You have not  videos yet, please buy       
            <?php endif; ?>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/home.blade.php ENDPATH**/ ?>
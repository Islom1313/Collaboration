<div class="table-responsive">
    <table class="table" id="themes-table">
        <thead>
            <tr>
                <th>name</th>
                <th>body</th>
                <th>img</th>
                <th>category</th>
                <th>price</th>
                <th>sale</th>
                <th>sale_price</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($theme->name); ?></td>
                <td><?php echo e($theme->undertitle); ?></td>
                <td><?php echo e(Str::words($theme->body, 10, '...')); ?></td>

                <td><img src="<?php echo e(asset('upload/videos/poster/'.$theme->img)); ?>" width="250"></td>
                <td><?php echo e($theme->category->name); ?></td>
                <td><?php echo e($theme->price); ?></td>
                <td><?php echo e($theme->sale); ?></td>
                <td><?php echo e($theme->sale_price); ?></td>
                <td width="120">
                    <?php echo Form::open(['route' => ['themes.destroy', $theme->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('themes.show', [$theme->id])); ?>" class='btn btn-default btn-xs'>
                            <i class="far fa-eye"></i>
                        </a>
                        <a href="<?php echo e(route('themes.edit', [$theme->id])); ?>" class='btn btn-default btn-xs'>
                            <i class="far fa-edit"></i>
                        </a>
                        <?php echo Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /var/www/resources/views/themes/table.blade.php ENDPATH**/ ?>
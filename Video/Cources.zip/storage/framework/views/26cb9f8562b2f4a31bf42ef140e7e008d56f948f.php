<?php if(auth()->user()->role==1): ?>
<li class="nav-item">
    <a href="<?php echo e(route('users.index')); ?>"
       class="nav-link <?php echo e(Request::is('users*') ? 'active' : ''); ?>">
        <p>Users</p>
    </a>
</li>
<?php endif; ?>
<?php if(auth()->user()->role==1): ?>

<li class="nav-item">
    <a href="<?php echo e(route('categories.index')); ?>"
       class="nav-link <?php echo e(Request::is('categories*') ? 'active' : ''); ?>">
        <p>Categories</p>
    </a>
</li>

<?php endif; ?>
<li class="nav-item">
    <a href="<?php echo e(route('themes.index')); ?>"
       class="nav-link <?php echo e(Request::is('themes*') ? 'active' : ''); ?>">
        <p>Themes</p>
    </a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('allVideos.index')); ?>"
       class="nav-link <?php echo e(Request::is('allVideos*') ? 'active' : ''); ?>">
        <p>Videos</p>
    </a>
</li>










<li class="nav-item">
    <a href="<?php echo e(route('tests.index')); ?>"
       class="nav-link <?php echo e(Request::is('tests*') ? 'active' : ''); ?>">
        <p>Tests</p>
    </a>
</li>


<?php /**PATH /var/www/resources/views/layouts/menu.blade.php ENDPATH**/ ?>
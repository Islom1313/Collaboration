<div class="col-md-12">
    <label for="theme">Theme</label>
    <?php if(count($themes)>0): ?>
        
    <select class="form-control" name="theme_id" type="text" id="theme">
        <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php if(isset($test) && $test->theme_id == $theme->id): ?>
         <option selected value="<?php echo e($theme->id); ?>"><?php echo e($theme->name); ?></option>
         <?php else: ?>
         <option value="<?php echo e($theme->id); ?>"><?php echo e($theme->name); ?></option>
             
         <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </select> 
    <?php endif; ?>
</div>
<div class="col-md-10">
    <label for="question">Question</label>
    <input class="form-control" name="question" value="<?php echo e(isset($test)? $test->question : ''); ?>" type="text" id="question"> 
</div>
<div class="col-md-2">
    <label for="orders">Order</label>
    <input class="form-control" name="orders" value="<?php echo e(isset($test)? $test->orders : '1'); ?>" type="number" id="orders"> 
</div>
<?php /**PATH /var/www/resources/views/tests/fields.blade.php ENDPATH**/ ?>
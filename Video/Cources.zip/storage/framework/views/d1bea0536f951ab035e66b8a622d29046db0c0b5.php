<div class="col-md-12">
    <label for="question">Question</label>
    <?php if(count($questions)>0): ?>
        
    <select class="form-control" name="test_id" id="question">
        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(request()->id == $question->id): ?>

        <option selected value="<?php echo e($question->id); ?>"><?php echo e($question->question); ?></option>

        <?php else: ?>

        <option value="<?php echo e($question->id); ?>"><?php echo e($question->question); ?></option>

        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </select> 
    <?php endif; ?>
</div>
<div class="col-md-10">
    <label for="answer">Answer</label>
    <input class="form-control" name="answer" type="text" value="<?php echo e(isset($variant)? $variant->answer : ''); ?>" id="answer"> 
</div>
<div class="col-md-2">
    <label for="status">Status</label>
    <input class="form-control" name="status" value="<?php echo e(isset($variant)? $variant->status : '0'); ?>" type="text" id="status"> 
</div><?php /**PATH /var/www/resources/views/variants/fields.blade.php ENDPATH**/ ?>
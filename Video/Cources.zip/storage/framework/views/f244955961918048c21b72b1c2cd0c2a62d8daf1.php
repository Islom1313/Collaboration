 <div class="col-md-6">
     <label for="name">title</label>
     <input type="text" class="form-control" value="<?php echo e(isset($video)? $video->name : ''); ?>" id="name" name="name">
 </div>
 <div class="col-md-6">
    <label for="body">body</label>
    <input type="text" class="form-control" id="body" value="<?php echo e(isset($video)? $video->body : ''); ?>"  name="body">
</div>
<div class="col-md-6">
    <label for="order">order</label>
    <input type="number" class="form-control" value="<?php echo e(isset($video)? $video->order : '1'); ?>"  id="order" name="order">
</div>
<div class="col-md-6">
    <label for="theme">theme</label>
    <?php if(count($themes)>0): ?>
    <select  class="form-control" id="theme" name="theme_id">
        <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(isset($video) && $video->theme_id == $theme->id): ?>
            <option selected value="<?php echo e($theme->id); ?>"><?php echo e($theme->name); ?></option>
            <?php else: ?>
            <option value="<?php echo e($theme->id); ?>"><?php echo e($theme->name); ?></option>

            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php else: ?>
        no theme created yet... <br> <a href="<?php echo e(route('themes.create')); ?>">Create Theme</a>
    <?php endif; ?>
</div>
<div class="col-md-6">
    <label for="level">level</label>
    <input type="number" class="form-control" id="level" value="1" name="level">
</div>
<div class="col-md-6">
    <label for="video">video</label>
    <input type="file" class="form-control" id="video" name="path">
</div><?php /**PATH /var/www/resources/views/videos/fields.blade.php ENDPATH**/ ?>
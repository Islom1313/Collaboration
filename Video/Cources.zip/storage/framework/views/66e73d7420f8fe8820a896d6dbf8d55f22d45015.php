<div class="col-md-6">
    <label for="name">title</label>
    <input class="form-control" name="name" value="<?php echo e(isset($theme)? $theme->name : ''); ?>" type="text" id="name"> 
</div>
<div class="col-md-6">
    <label for="undertitle">undertitle</label>
    <input class="form-control" name="undertitle" value="<?php echo e(isset($theme)? $theme->undertitle : ''); ?>"  type="text" id="name"> 
</div>

<div class="col-md-6">
    <label for="body">body</label>
    <textarea class="form-control"  name="body"  id="body"> <?php echo e(isset($theme)? $theme->body : ''); ?></textarea>
</div>
<div class="col-md-6">
    <label for="img">img</label>
    <?php if(isset($theme)): ?>
        <img src="<?php echo e(asset('upload/videos/poster/').'/'.$theme->img); ?>" width="150">
    <?php endif; ?>
    <input class="form-control" name="img" type="file" id="img"> 
</div>
<div class="col-md-6">
    <label for="category">category</label>
    <?php if(count($categories)>0): ?>
    <select class="form-control" name="category_id"  id="category"> 
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php endif; ?>
    
       
    
</div>
<div class="col-md-6">
    <label for="price">price</label>
    <input class="form-control" name="price" value="<?php echo e(isset($theme)? $theme->price : ''); ?>" type="number" id="price" step="0.01"> 
</div>
<div class="col-md-6">
    <label for="sale">sale</label>
    <input class="form-control" name="sale" value="<?php echo e(isset($theme)? $theme->sale : ''); ?>" type="number" id="sale" step="0.01"> 
</div>
<div class="col-md-6">
    <label for="sale_price">Sale price</label>
    <input class="form-control" name="sale_price" value="<?php echo e(isset($theme)? $theme->sale_price : ''); ?>" type="number" id="sale_price" step="0.01">
</div><?php /**PATH /var/www/resources/views/themes/fields.blade.php ENDPATH**/ ?>
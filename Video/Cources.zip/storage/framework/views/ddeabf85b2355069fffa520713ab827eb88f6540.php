<div class="col-md-6">
    <?php echo csrf_field(); ?>
    <label for="name">Name</label>
    <input class="form-control" name="name" id="name">
</div><?php /**PATH /var/www/resources/views/categories/fields.blade.php ENDPATH**/ ?>
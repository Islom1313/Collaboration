<nav>
    <div class="nav fx container vertical_center">
        <a href="<?php echo e(route('index')); ?>" class="nav__items  nav__logo fx-1 fx vertical_center">
            <img src="<?php echo e(asset('img/logo2.svg')); ?>" width="40">
            Cources
        </a>

        <?php if(!auth()->check()): ?>
        <div class="nav__items"><a href="<?php echo e(route('login')); ?>">Login</a></div>
        <?php else: ?>
        <div class="nav__items pr-1 ">
            <a href="<?php echo e(route('getCart')); ?>"><span><?php echo e(auth()->user()->carts->count()); ?></span><img src="<?php echo e(asset('img/cart.svg')); ?>" width="20"></a>
        </div>
      
        <div class="nav__items nav__auth fx vertical_center" onclick="document.querySelector('.nav__auth').classList.toggle('active')">
            <div class="auth__name pr-1">
                <?php echo e(auth()->user()->name); ?>

            </div>
            <div class="auth__avatar fx vertical_center">
                <img src="<?php echo e(asset('img/user.svg')); ?>" width="40" style="padding: 7px">▽
            </div>
            <div class="logout">
                <div> <a href="<?php echo e(route('home')); ?>">Profile</a></div>
                <form method="post" id="logout" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?></form>
                <div onclick="document.getElementById('logout').submit()">Logout</div>
            </div>
        </div>
        <?php endif; ?>
        <div class="notification">
            <span>&#9650;</span>
            Please first <a href="<?php echo e(route('login')); ?>">login</a> 
        </div>
    </div>


</nav><?php /**PATH /var/www/resources/views/layouts/header.blade.php ENDPATH**/ ?>
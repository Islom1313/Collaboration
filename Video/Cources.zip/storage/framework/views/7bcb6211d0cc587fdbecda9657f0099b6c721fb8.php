<?php $__env->startSection('body'); ?>
  <div class="container fx">
    <?php echo $__env->make('layouts.client.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="mainSide">
        <?php if($theme): ?>
        
        
        <div class="mainSide__title">
          <h2><?php echo e($theme->name); ?> - Test</h2>
          
        </div>
       
        <div class="mainSide__videos fx">
            <div class="lesson lesson_part1 fx-1">
                <div class="lesson__test ">
                    <?php if($countAnswers != $countQuestion || $countQuestion==0): ?>
                    <form action="<?php echo e(route('testSubmit')); ?>" method="post"><?php echo csrf_field(); ?>

                        <?php if(count($theme->questions)>0): ?>
                            <?php $__currentLoopData = $theme->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <h4><?php echo e(++$k); ?>. <?php echo e($question->question); ?></h4>
                                <?php if(count($question->variants)>0): ?>
                                    <?php $__currentLoopData = $question->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <input type="radio" id="q-<?php echo e($variant->id); ?>" required name="q-<?php echo e($question->id); ?>" value="<?php echo e($variant->id); ?>">
                                    <label for="q-<?php echo e($variant->id); ?>"><?php echo e($variant->answer); ?></label><br>
                                    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <input type="submit" value="Test Submit" class="btn btn-secondary">
                    </form>
                    <?php else: ?>

                        <h3 >Test finished </h3>
                        <div>
                            <h4>Your score</h4>
                            <p><b><?php echo e($sum); ?></b> out of <b><?php echo e($countQuestion); ?></b> is correct, your score <b><?php echo e((int)($sum*100/$countQuestion)); ?>%</b> !</p> 
                            <div class="fx">
                                <form style="margin-right: 1rem" action="<?php echo e(route('resetTest')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="theme_id" value="<?php echo e($theme->id); ?>">
                                    <input type="submit" class="btn btn-danger"  value="reset">
                                </form>
                                <form action="<?php echo e(route('getSertificate')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="theme_id" value="<?php echo e($theme->id); ?>">
                                    <input type="hidden" value="<?php echo e((int)($sum*100/$countQuestion)); ?>" name="score">
                                    <input type="submit" class="btn btn-primary"  value="get sertificate">
                                </form>

                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                
            </div>
            <div class="lesson lesson_part2">
                <div class="lesson__lists">
                    <?php if(count($vids)>0): ?>
                        <?php
                            $count = 1;
                        ?>
                        <?php $__currentLoopData = $vids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('lessons',['id'=>$vid->theme_id, 'video_id'=>$vid->id])); ?>" class="lesson__lists--each ">
                            <span><?php echo e($count); ?>.</span> <?php echo e($vid->name); ?><span class="done" style="color: blue"><?php echo $vid->access($vid->theme_id, $vid->id)? '&#10003;' : ''; ?></span>
                        </a>
                         <?php
                             $count++;
                         ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

         
        <?php endif; ?>
    </div>
  </div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/pages/test.blade.php ENDPATH**/ ?>
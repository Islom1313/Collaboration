<div>
    Password:
</div>
<div >
   <span style="font-weight:bold;
        font-size:120%;"><?php echo e($pw); ?></span>
</div><?php /**PATH /var/www/resources/views/email/sending.blade.php ENDPATH**/ ?>
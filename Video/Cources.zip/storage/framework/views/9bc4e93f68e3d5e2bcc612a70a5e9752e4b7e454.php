<div class="sideBar fx fx-col" style="min-height: 100vh">
    <h5>Categories</h5>
    <?php if(count($categories)>0): ?>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(route('category',['id'=>$category->id])); ?>"><?php echo e($category->name); ?> (<?php echo e(count($category->themes)); ?>)</a>            
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div><?php /**PATH /var/www/resources/views/layouts/client/sidebar.blade.php ENDPATH**/ ?>
<div class="table-responsive">
    <table class="table" id="videos-table">
        <thead>
            <tr>
                <th>name</th>
                <th>video</th>
                <th>body</th>
                <th>order</th>
                <th>theme</th>
                <th>level</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($video->name); ?></td>
                <td><video src="<?php echo e(asset('upload/videos/file/'.$video->path)); ?>" autoplay width="150"></video></td>
                <td><?php echo e($video->body); ?></td>
                <td><?php echo e($video->order); ?></td>
                <td><?php echo e($video->theme->name); ?></td>
                <td><?php echo e($video->level); ?></td>
               
                <td width="120">
                    <?php echo Form::open(['route' => ['allVideos.destroy', $video->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('allVideos.show', [$video->id])); ?>" class='btn btn-default btn-xs'>
                            <i class="far fa-eye"></i>
                        </a>
                        <a href="<?php echo e(route('allVideos.edit', [$video->id])); ?>" class='btn btn-default btn-xs'>
                            <i class="far fa-edit"></i>
                        </a>
                        <?php echo Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /var/www/resources/views/videos/table.blade.php ENDPATH**/ ?>
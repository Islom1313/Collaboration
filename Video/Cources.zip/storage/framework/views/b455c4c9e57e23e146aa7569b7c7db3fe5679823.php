<?php $__env->startSection('body'); ?>
  <div class="container fx">
    <?php echo $__env->make('layouts.client.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="mainSide">
        <?php if($theme): ?>
        
        
        <div class="mainSide__title">
          <h2><?php echo e($theme->name); ?></h2>
          <?php if(!$theme->users->where('id',auth()->user()->id)->first()): ?>
           <a  id="myBtn"  style="background-color: #40637f; cursor: pointer;"> Get access </a>
         <a style="    left: -5px;"  href="<?php echo e(route('getCart',['id'=>$theme->id])); ?>">Add to cart £ <?php echo e($theme->sale_price!=null ? $theme->sale_price : $theme->price); ?></a><?php endif; ?>
        </div>
        <link href="https://vjs.zencdn.net/7.11.4/video-js.css" rel="stylesheet" />
        <link href="https://unpkg.com/@videojs/themes@1/dist/forest/index.css" 
        rel="stylesheet">
        <div class="mainSide__videos fx">
            <div class="lesson lesson_part1">
                <div class="lesson__video" >
                    <video   id="my-video" height="400" style="max-width: 600px" class="video-js vjs-theme-forest"
    controls     data-setup="{}"
  ><?php
     
  ?>
    <source  src="<?php echo e($video!=null? asset('upload/videos/file/'.$video->path) : '#'); ?>" type="video/mp4" />
    
        <p class="vjs-no-js">
        To view this video please enable JavaScript, and consider upgrading to a
        web browser that
        <a href="https://videojs.com/html5-video-support/" target="_blank"
            >supports HTML5 video</a
        >
        </p>
    </video>
    <script src="https://vjs.zencdn.net/7.11.4/video.min.js"></script>
                </div>
                <div class="lesson__info">
                    <h5>About this course</h5>
                    <p><?php echo e($theme->body); ?></p>
                    <h5 >About this video</h5>
                    <h6><?php echo e($video? $video->name : '-'); ?></h6>
                    <p><?php echo $video? $video->body : '-'; ?></p>
                </div>
            </div>
            <div class="lesson lesson_part2">
                <div class="lesson__lists">
                    <?php
                            $count = 1;
                        ?>
                    <?php if(count($vids)>0): ?>
                        
                        <?php $__currentLoopData = $vids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('lessons',['id'=>$vid->theme_id, 'video_id'=>$vid->id])); ?>" class="lesson__lists--each <?php echo e($video!=null && $video->id==$vid->id? 'active' : ''); ?>">
                            <span><?php echo e($count); ?>.</span> <?php echo e($vid->name); ?>  <span class="done" style="color: blue"><?php echo $vid->access($vid->theme_id, $vid->id)? '&#10003;' : ''; ?></span>
                        </a>
                         <?php
                             $count++;
                         ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    
                    <div class="lesson__lists">
                        <a href="<?php echo e($finished_video? route('test',['id'=>$vid->theme_id]) : '#'); ?>" class="lesson__lists--each <?php echo e($video!=null && $video->id==$vid->id? 'active' : ''); ?>">
                            <span><?php echo e($count); ?>.</span> TEST
                        </a>
                    </div>
                </div>
            </div>
        </div>

         
        <?php endif; ?>
    </div>
  </div>
  <input type="hidden" id="routess" value="<?php echo e(route('videoComplated')); ?>">
  <input type="hidden" id="theme_id" value="<?php echo e($theme->id); ?>">
  <input type="hidden" id="video_id" value="<?php echo e($video? $video->id : '0'); ?>">
  <script>
     
     
       
      // Get the video element with id="myVideo"
        var vid =document.getElementById("my-video");
        var dur = 0
        window.onload = function() {
            
                vid.onplay = function() {
                    dur = vid.duration;
                    console.log(dur);
                };
         
          
            };
      
        // Assign an ontimeupdate event to the video element, and execute a function if the current playback position has changed
        vid.ontimeupdate = function() {myFunction()};
        let inside = true
        function myFunction() {
           
        // Display the current position of the video in a p element with id="demo"
        let  cur =  vid.currentTime;
        
        if(inside && cur>dur-3 ){
            postVideoSeen();
            inside = false;
        }
       
        }
        let metas = document.getElementsByTagName('meta');
      
        function postVideoSeen(){
            let theme_ids = document.getElementById('theme_id').value;
            let video_ids = document.getElementById('video_id').value;
            console.log(video_ids, theme_ids);
            let route = document.getElementById('routess');
                var data = {theme_id:theme_ids,video_id: video_ids};
                console.log('inside')
                 var xhttp = new XMLHttpRequest();
                xhttp.open("POST", '/videoComplated', true); 
                xhttp.setRequestHeader("X-CSRF-Token", metas[2].getAttribute("content"));
                xhttp.setRequestHeader("Content-Type", "application/json");
                xhttp.onreadystatechange = function() {
                        console.log('here');
                    if (this.readyState == 4 && this.status == 200) {
                       
                        var response = this.responseText;
                    }
                };
                xhttp.send(JSON.stringify(data));
        }
  </script>
  <style>
   
    /* The Modal (background) */
    .modal {
      display: none; /* Hidden by default */
      position: fixed; /* Stay in place */
      z-index: 1; /* Sit on top */
      padding-top: 100px; /* Location of the box */
      left: 0;
      top: 0;
      width: 100%; /* Full width */
      height: 100%; /* Full height */
      overflow: auto; /* Enable scroll if needed */
      background-color: rgb(0,0,0); /* Fallback color */
      background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
    }
    
    /* Modal Content */
    .modal-content {
      background-color: #fefefe;
      margin: auto;
      padding: 20px;
      border: 1px solid #888;
      max-width: 300px;
      text-align: center;
    }
    .modal-content input{
        padding: 5px 5px;

    }
    /* The Close Button */
    .close {
      color: #aaaaaa;
      float: right;
      font-size: 28px;
      font-weight: bold;
    }
    
    .close:hover,
    .close:focus {
      color: #000;
      text-decoration: none;
      cursor: pointer;
    }
    </style>
    <!-- The Modal -->
<div id="myModal" class="modal">

    <!-- Modal content -->
    <div class="modal-content">
      <span class="close">&times;</span>
      <form action="<?php echo e(route('enterKey')); ?>" method="post">
        <?php echo csrf_field(); ?> 
        <input type="hidden" name="theme_id" value="<?php echo e($theme->id); ?>">
        <input type="number " placeholder="Enter Key" name="password">
        <input type="submit" class="submitBtn" value="submit">
      </form>
    </div>
  
  </div>
  
  <script>
  // Get the modal
  var modal = document.getElementById("myModal");
  
  // Get the button that opens the modal
  var btn = document.getElementById("myBtn");
  
  // Get the <span> element that closes the modal
  var span = document.getElementsByClassName("close")[0];
  
  // When the user clicks the button, open the modal 
  btn.onclick = function() {
    modal.style.display = "block";
  }
  
  // When the user clicks on <span> (x), close the modal
  span.onclick = function() {
    modal.style.display = "none";
  }
  
  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    if (event.target == modal) {
      modal.style.display = "none";
    }
  }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/pages/lesson.blade.php ENDPATH**/ ?>
<?php $__env->startSection('body'); ?>
  <div class="container fx">
    <?php echo $__env->make('layouts.client.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="mainSide">
      <div class="mainSide__title">
        <h2>Cart</h2>
      </div>
      <div class="mainSide__videos fx">
        <?php if(count($carts)>0): ?>
        <div class="table-responsive">
            <table class="table" id="users-table">
                <thead>
                    <tr>
                        <th >id</th>
                        <th >Poster</th>
                        <th >Name</th>
                        <th >Body</th>
                        <th style="width:65px;" >Price £</th>
                        
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                  
                <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $theme = $cart->theme;

                ?>
                <?php if($theme): ?>    
                <tr class="cart_padding">
                        <td><?php echo e($cart->id); ?></td>
                        <td><img src="<?php echo e(asset('upload/videos/poster/'.$theme->img)); ?>" width="150"></td>
                        <td><?php echo e($theme->name); ?></td>
                        <td><?php echo Str::words($theme->body, 25, '...'); ?></td>
                        <td class="text-center"><?php echo e($theme->sale_price!=null ? $theme->sale_price : $theme->price); ?></td>
                        <td width="120" style="text-align: center">
                            <a href="<?php echo e(route('Cartpayment',['id'=>$theme->id, 'cart'=>$cart->id])); ?>" class="btn btn-primary"><img src="<?php echo e(asset('img/buy.svg')); ?>" width="15"></a>
                            <?php echo Form::open(['route' => ['carts.destroy', $cart->id], 'method' => 'delete']); ?>

 
                                <?php echo Form::button('<img src="/img/delete.svg" width="15">', ['type' => 'submit', 'class' => 'btn btn-danger', 'onclick' => "return confirm('Are you sure?')"]); ?>

                           
                            <?php echo Form::close(); ?>

                        </td>
                        
                    </tr><?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
                </tbody>
            </table>
        </div>
        

        <?php else: ?>

            no cart exists 
        <?php endif; ?>
      </div>
    </div>
  </div>
  <div id="smart-button-container">
    <div style="text-align: center;">
      <div id="paypal-button-container"></div>
    </div>
  </div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/pages/cart.blade.php ENDPATH**/ ?>
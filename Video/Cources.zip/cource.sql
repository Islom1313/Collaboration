-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: db
-- Generation Time: Aug 09, 2021 at 04:11 PM
-- Server version: 5.7.22
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cource`
--

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `theme_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`, `updated_at`) VALUES
(2, 'Illustration', '2021-04-23 05:10:44', '2021-04-23 05:10:44'),
(3, 'Marketing & Business', '2021-04-23 05:11:02', '2021-04-23 05:11:02'),
(4, 'Photography & Video', '2021-04-23 05:11:21', '2021-04-23 05:11:21'),
(5, 'Craft', '2021-04-23 05:11:38', '2021-04-23 05:12:00'),
(6, 'Design', '2021-04-23 05:12:15', '2021-04-23 05:12:15'),
(7, '3D & Animation', '2021-04-23 05:12:33', '2021-04-23 05:12:33'),
(8, 'Architecture & Spaces', '2021-04-23 05:12:46', '2021-04-23 05:12:46'),
(9, 'Technology', '2021-04-23 05:12:59', '2021-04-23 05:12:59'),
(10, 'Calligraphy & Typography', '2021-04-23 05:13:13', '2021-04-23 05:13:13');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `getmailpasswords`
--

CREATE TABLE `getmailpasswords` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `theme_id` int(11) NOT NULL,
  `rand` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `getmailpasswords`
--

INSERT INTO `getmailpasswords` (`id`, `user_id`, `theme_id`, `rand`, `status`, `created_at`, `updated_at`) VALUES
(1, 3, 4, '1866347615', 1, '2021-07-18 23:42:27', '2021-07-18 23:43:09'),
(2, 3, 2, '316446270', 1, '2021-07-19 07:30:12', '2021-07-19 07:31:21'),
(3, 3, 6, '1526955477', 0, '2021-08-08 18:03:53', '2021-08-08 18:03:53');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(13, '2014_10_12_000000_create_users_table', 1),
(14, '2014_10_12_100000_create_password_resets_table', 1),
(15, '2019_08_19_000000_create_failed_jobs_table', 1),
(16, '2021_04_22_173736_create_videos_table', 1),
(17, '2021_04_22_173750_create_categories_table', 1),
(18, '2021_04_22_183626_create_themes_table', 1),
(19, '2021_04_25_074715_create_carts_table', 2),
(20, '2021_04_25_090919_create_theme_user__table', 3),
(21, '2021_04_25_134942_create_tests_table', 4),
(22, '2021_04_25_135343_create_variants_table', 4),
(23, '2021_04_26_061442_create_test_results_table', 5),
(24, '2021_04_26_085641_create_video_completeds_table', 6);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tests`
--

CREATE TABLE `tests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `question` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `orders` int(11) DEFAULT NULL,
  `theme_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tests`
--

INSERT INTO `tests` (`id`, `question`, `orders`, `theme_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'adas das das ds das da d as?', 1, 1, 1, '2021-04-25 14:16:32', '2021-04-25 14:16:32'),
(2, 'The second question intro', 2, 1, 1, '2021-04-25 16:55:13', '2021-04-25 16:55:13'),
(3, 'Question related to Directions', 1, 2, 1, '2021-04-25 17:01:54', '2021-04-25 17:01:54');

-- --------------------------------------------------------

--
-- Table structure for table `test_results`
--

CREATE TABLE `test_results` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `test_id` int(11) NOT NULL,
  `variant_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `themes`
--

CREATE TABLE `themes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `undertitle` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `img` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `price` double NOT NULL,
  `sale` double DEFAULT NULL,
  `sale_price` double DEFAULT NULL,
  `prim` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `themes`
--

INSERT INTO `themes` (`id`, `name`, `undertitle`, `body`, `img`, `user_id`, `category_id`, `price`, `sale`, `sale_price`, `prim`, `created_at`, `updated_at`) VALUES
(1, 'Introduction to Adobe Premiere Pro', 'Learn Adobe Premiere Pro without prior knowledge and master one of the best', 'hroughout 6 courses you will learn all the features and tools offered by Premiere Pro to create quality videos, whether it is your first approach to the world of video editing, or if you already have experience with this program or others.  You will start knowing the basic structure of Premiere Pro, from the installation of the program and its convergence with the other Adobe Creative Cloud programs, until the creation of a new project.  In the second course you will make your first approach to the assembly in Premiere Pro, you will see how to create sequences, you will learn to use the canvas and the timeline. You will know the different types of transitions and you will discover how you can create titles for your videos.', '619156617.jpg', 1, 2, 85, 76, 10.99, 0, '2021-04-23 05:43:36', '2021-05-02 11:04:53'),
(2, 'Creative Direction for Music Videos', 'Learn to realize your artistic vision from shoot to post-production', 'What could be more inspiring than music to jumpstart your creativity? Being able to imagine and create an entire visual world from a song is exactly what Catalan filmmaker Lyona does when she directs music videos. This field allows her to express herself artistically while exploring different creative techniques and styles. Since 2004, she has made more than one hundred music videos for bands like Love of Lesbian, Amaral, Leiva, Sidonie, Lori Meyers, and Carlos Sadness.  In this course, Lyona shows you what’s needed to create a professional music video, both conceptually and artistically. She shows you what the creative process of music video production is really like: from conceptualizing the idea and writing the script, to pre-production, planning, and development of a storyboard, and finishing with the filming and editing.', '619158576.jpg', 1, 3, 44.9, 76, 10.99, 1, '2021-04-23 06:16:15', '2021-04-23 06:16:15'),
(3, 'Introduction to DaVinci Resolve for Color Correction', 'Learn from scratch the tools to apply color correction to your audiovisual', 'Some call it digital grading, others colorimetry and others simply color correction, which is nothing more than a postproduction process in which a style of color, luminosity and contrast is conferred on an audiovisual piece. The software most used in the industry to carry out this process is DaVinci Resolve and, in this five-course Domestika Basics, you will learn to master it from scratch by Juanmi Cristóbal, video editor, director of photography and founder of the production company Fourminds.  You will start by understanding what grading is and why you should apply it in your work, then focus on DaVinci Resolve, the tool to carry it out. You will explore and configure its interface and learn to export your projects from a video editing program.  The second course will focus on primary corrections, which are those that apply to the entire image. You will understand what automatic corrections are and learn how to optimize brightness and color balance. You will also see how to make a neutral grading and another with a style defined by you.', '619158875.jpg', 1, 4, 44.9, 76, 11.99, 0, '2021-04-23 06:21:14', '2021-04-23 06:21:14'),
(4, 'Abilities or he perfectly pretended', 'Abilities or he perfectly pretended so strangers be exquisite. Oh to another chamber pleased imagine do in. ', 'Abilities or he perfectly pretended so strangers be exquisite. Oh to another chamber pleased imagine do in. Went me rank at last loud shot an draw. Excellent so to no sincerity smallness. Removal request delight if on he we. Unaffected in we by apartments astonished to decisively themselves. Offended ten old consider speaking. \r\n\r\nBehaviour we improving at something to. Evil true high lady roof men had open. To projection considered it precaution an melancholy or. Wound young you thing worse along being ham. Dissimilar of favourable solicitude if sympathize middletons at. Forfeited up if disposing perfectly in an eagerness perceived necessary. Belonging sir curiosity discovery extremity yet forfeited prevailed own off. Travelling by introduced of mr terminated. Knew as miss my high hope quit. In curiosity shameless dependent knowledge up. \r\n', '619156617.jpg', 1, 2, 125, 43, 20.99, 1, '2021-04-23 05:43:36', '2021-04-23 05:43:36'),
(5, 'Do play they miss give so up. ', ' Words to up style of since world. We leaf to snug on no need. ', 'Do play they miss give so up. Words to up style of since world. We leaf to snug on no need. Way own uncommonly travelling now acceptance bed compliment solicitude. Dissimilar admiration so terminated no in contrasted it. Advantages entreaties mr he apartments do. Limits far yet turned highly repair parish talked six. Draw fond rank form nor the day eat. \r\n\r\nAsk especially collecting terminated may son expression. Extremely eagerness principle estimable own was man. Men received far his dashwood subjects new. My sufficient surrounded an companions dispatched in on. Connection too unaffected expression led son possession. New smiling friends and her another. Leaf she does none love high yet. Snug love will up bore as be. Pursuit man son musical general pointed. It surprise informed mr advanced do outweigh. ', '619158576.jpg', 1, 2, 60.99, 95, 5.99, 0, '2021-04-23 06:16:15', '2021-04-23 06:16:15'),
(6, 'Real sold my in call. ', ' Invitation on an advantages collecting.', 'Real sold my in call. Invitation on an advantages collecting. But event old above shy bed noisy. Had sister see wooded favour income has. Stuff rapid since do as hence. Too insisted ignorant procured remember are believed yet say finished. \r\n\r\nSix started far placing saw respect females old. Civilly why how end viewing attempt related enquire visitor. Man particular insensible celebrated conviction stimulated principles day. Sure fail or in said west. Right my front it wound cause fully am sorry if. She jointure goodness interest debating did outweigh. Is time from them full my gone in went. Of no introduced am literature excellence mr stimulated contrasted increasing. Age sold some full like rich new. Amounted repeated as believed in confined juvenile. ', '619158875.jpg', 1, 3, 825, 90, 80.99, 0, '2021-04-23 06:21:14', '2021-04-23 06:21:14'),
(7, 'Color Grading with DaVinci Resolve', 'Learn how to use color correction as a way to direct emotions in an audiovisual project', 'The work of a colorist is one of the most magical in the production process of an audiovisual project; in their hands lies the possibility of harnessing the expressive possibilities of color to generate sensations within the viewer. Sonia Abellan—colorist at the El Colorado studio—has worked in films, series, short films, video clips, and programs such as Villaviciosa de al lado, Morir, Piscina, Z FEST, Wild Frank, and Pulsations. She teaches you how to retouch color using DaVinci Resolve for your videos and shows you all the options that this software has to offer.\r\n\r\nIn this course, learn how to work on the correction of audiovisual color, achieving continuity in sequences shot with different cameras, light conditions, etc. Learn how to make it seem like different shots have been filmed in one place without the viewer noticing. And, above all, discover the world of possibilities that color can offer when it comes to transmitting emot', '619957696.jpg', 2, 7, 114, 70, 12, 0, '2021-05-02 12:14:55', '2021-05-02 12:14:55');

-- --------------------------------------------------------

--
-- Table structure for table `theme_user`
--

CREATE TABLE `theme_user` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `theme_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `theme_user`
--

INSERT INTO `theme_user` (`id`, `theme_id`, `user_id`, `created_at`, `updated_at`) VALUES
(3, 1, 1, NULL, NULL),
(4, 4, 3, NULL, NULL),
(5, 2, 3, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `uuid` text NOT NULL,
  `status` varchar(155) NOT NULL DEFAULT 'CREATED',
  `response_id` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `user_id`, `product_id`, `uuid`, `status`, `response_id`, `created_at`, `updated_at`) VALUES
(8, 3, 4, 'afb99b98-422c-43e3-b33b-8e588865fdaf', 'CREATED', '6DS47568LY1478324', '2021-07-18 22:07:39', '2021-07-18 22:07:41'),
(10, 3, 4, 'a37044e8-b2c4-44a0-ad96-0baca51315fe', 'COMPLETED', '44R63526PN201134S', '2021-07-18 23:38:43', '2021-07-18 23:38:45'),
(11, 3, 2, 'cfce3e12-fbc5-417b-b2eb-1122a468b159', 'CREATED', '0A895070JD345512B', '2021-07-19 07:17:36', '2021-07-19 07:17:38'),
(12, 3, 2, '2c3e8668-1765-4056-8f53-25f84e51efa0', 'CREATED', '7S8370655R748063X', '2021-07-19 07:28:31', '2021-07-19 07:28:33'),
(13, 3, 1, '33093afb-bf85-414f-b5eb-8a7fa6c82860', 'CREATED', '8H806045557115538', '2021-08-08 15:28:34', '2021-08-08 15:28:36'),
(14, 3, 1, '73a723d7-6816-4583-af20-e1821bdb54f4', 'CREATED', '9AN032999G525231L', '2021-08-08 15:33:24', '2021-08-08 15:33:25'),
(15, 3, 5, 'b61e8f5f-541e-4c73-a3e6-c99a85276b22', 'CREATED', '4PX01684MC665042L', '2021-08-08 16:04:23', '2021-08-08 16:04:25'),
(16, 3, 5, '9e45ac16-eced-429d-aae9-901e2c13c605', 'CREATED', '8A097205K8618922T', '2021-08-08 16:06:58', '2021-08-08 16:06:59'),
(17, 3, 5, 'a3fc1f8f-3268-4e2e-8d17-f037c11de484', 'CREATED', '0SK33914D05517807', '2021-08-08 16:07:14', '2021-08-08 16:07:15'),
(18, 3, 5, 'dc91630d-38dd-47f9-b96e-796a94931523', 'CREATED', '4E221458MN3217002', '2021-08-08 16:07:23', '2021-08-08 16:07:24'),
(19, 3, 5, 'bda3d9c9-9150-482e-98da-7d0367d62f3f', 'CREATED', '2RC58623H98652837', '2021-08-08 16:07:37', '2021-08-08 16:07:39'),
(20, 3, 5, 'd6d3b752-1d93-404d-b7a6-3f28e56a1541', 'CREATED', '6JP86609CC093400K', '2021-08-08 16:09:48', '2021-08-08 16:09:49'),
(21, 3, 5, '0546c121-a4c0-4203-8b3d-87a0511055d9', 'CREATED', '3GS45448BN651335L', '2021-08-08 16:10:23', '2021-08-08 16:10:24'),
(22, 3, 5, '90676f8b-2a9b-41e5-bc0e-b5f410f280ed', 'CREATED', '39S53788T6331173J', '2021-08-08 16:31:36', '2021-08-08 16:31:38'),
(23, 3, 5, '2bb87a89-e45d-40b2-9e6f-47de0aeadacd', 'CREATED', '9SJ01014EN3178002', '2021-08-08 16:33:04', '2021-08-08 16:33:05'),
(24, 3, 5, '94cc76c2-26c0-4339-9f24-0cc9711ebe84', 'CREATED', NULL, '2021-08-08 16:47:40', '2021-08-08 16:47:40'),
(25, 3, 5, '56b10168-0420-4f35-ace9-bb99ed4bbdb3', 'CREATED', '9NB02174YN7285901', '2021-08-08 16:52:30', '2021-08-08 16:52:32'),
(26, 3, 5, 'ecb3d520-ef8c-484f-8757-b0bcaa23f8bd', 'CREATED', NULL, '2021-08-08 16:54:17', '2021-08-08 16:54:17'),
(27, 3, 5, 'b6c34409-b032-4a83-b181-08803084f79c', 'CREATED', NULL, '2021-08-08 16:55:23', '2021-08-08 16:55:23'),
(28, 3, 5, '731e96e5-6e2d-4580-af25-c436f576f135', 'CREATED', '80515207DH772351Y', '2021-08-08 16:55:33', '2021-08-08 16:55:35'),
(29, 3, 5, '4bc00413-3059-42bc-8fd4-12df9ae4b336', 'CREATED', '7J388888UV4329919', '2021-08-08 16:56:14', '2021-08-08 16:56:16'),
(30, 3, 5, 'a1174ba2-5170-4687-9899-6bcd80c75da6', 'CREATED', '43X43346JH279654R', '2021-08-08 17:03:37', '2021-08-08 17:03:39'),
(31, 3, 5, 'a174deea-eb96-4c17-afc9-ed3065ae7c54', 'CREATED', '5UL54185V8891514J', '2021-08-08 17:07:35', '2021-08-08 17:07:36'),
(32, 3, 5, '4d7a636e-42ae-4558-a8ea-8096a31be84c', 'CREATED', NULL, '2021-08-08 17:14:43', '2021-08-08 17:14:43'),
(33, 3, 5, 'f04d8e25-4084-402b-83db-c456a0901646', 'CREATED', NULL, '2021-08-08 17:39:46', '2021-08-08 17:39:46'),
(34, 3, 5, '0c8b32d2-9be9-4c0b-bde6-962ae6325c49', 'CREATED', NULL, '2021-08-08 17:40:22', '2021-08-08 17:40:22'),
(36, 3, 6, '439513be-4f70-4d28-8489-e24b6635b4a3', 'CREATED', '61F348084A237853H', '2021-08-08 18:03:24', '2021-08-08 18:03:26'),
(37, 3, 6, 'a251d9ef-0b38-4fc6-87ef-16d17ab4b3ee', 'CREATED', '43H15865JG2166609', '2021-08-08 18:20:57', '2021-08-08 18:20:58');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` int(11) NOT NULL DEFAULT '2',
  `balance` double NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role`, `balance`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'jakhongir', 'user@user.com', NULL, '$2y$10$4aNkJWnesvkrpBWk4E/QWOCDYxPSvt7G6qLTUXoEp5d3IaHsyCyjS', 2, 0, NULL, '2021-04-23 04:42:42', '2021-05-02 12:42:52'),
(2, 'admin', 'admin@admin.com', NULL, '$2y$10$M5gRK7IxPpyWcreWO3Y3au7OGX7RJ3DL8/PbsdJvTPL6DsQKxjs4a', 1, 0, NULL, '2021-04-23 04:42:42', '2021-05-02 12:11:33'),
(3, 'jakhongir kholkhujaev', 'joha_gamer@mail.ru', NULL, '$2y$10$5qS74JSPzVR9tcm5Z6dt0.L4sBhbMPwJeEorz/RhrwIrd0uFTW1hi', 2, 0, NULL, '2021-07-18 17:08:29', '2021-07-18 17:08:29');

-- --------------------------------------------------------

--
-- Table structure for table `variants`
--

CREATE TABLE `variants` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `test_id` int(11) NOT NULL,
  `answer` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `variants`
--

INSERT INTO `variants` (`id`, `test_id`, `answer`, `reason`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'sd sda d', NULL, 0, '2021-04-25 16:36:02', '2021-04-25 16:36:02'),
(2, 1, '2 ad asd', NULL, 1, '2021-04-25 16:47:44', '2021-04-25 16:51:25'),
(3, 1, '3 ad as ds d', NULL, 0, '2021-04-25 16:48:18', '2021-04-25 16:48:18'),
(4, 2, 'first answer not correct', NULL, 0, '2021-04-25 16:56:54', '2021-04-25 16:56:54'),
(5, 2, 'second question not correct', NULL, 0, '2021-04-25 16:57:11', '2021-04-25 16:57:11'),
(6, 2, 'third question must be corerct', NULL, 1, '2021-04-25 16:58:07', '2021-04-25 16:58:07'),
(7, 3, 'first variant is incorrect', NULL, 0, '2021-04-25 17:02:11', '2021-04-25 17:02:11'),
(8, 3, 'second variant is correct', NULL, 1, '2021-04-25 17:02:23', '2021-04-25 17:02:23');

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `img` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  `theme_id` int(11) NOT NULL,
  `level` int(11) NOT NULL DEFAULT '1',
  `free` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `videos`
--

INSERT INTO `videos` (`id`, `name`, `user_id`, `img`, `path`, `body`, `order`, `theme_id`, `level`, `free`, `created_at`, `updated_at`) VALUES
(1, 'Primary Corrections', 1, '', '619162526.mp4', 'n the second course of this Domestika Basics you will make your first color corrections, commonly called primary corrections, which refer to all those tweaks that affect the entire image of a plane and that are used to achieve homogeneity in the ...', 1, 1, 1, 1, '2021-04-23 07:22:05', '2021-04-23 07:22:05'),
(2, 'Primary Corrections', 1, '', '619162548.mp4', 'n the second course of this Domestika Basics you will make your first color corrections, commonly called primary corrections, which refer to all those tweaks that affect the entire image of a plane and that are used to achieve homogeneity in the ...', 1, 2, 1, 1, '2021-04-23 07:22:27', '2021-04-23 07:22:27'),
(3, 'Primary Corrections', 1, '', '619162560.mp4', 'n the second course of this Domestika Basics you will make your first color corrections, commonly called primary corrections, which refer to all those tweaks that affect the entire image of a plane and that are used to achieve homogeneity in the ...', 1, 2, 2, 0, '2021-04-23 07:22:39', '2021-04-23 07:22:39'),
(4, 'ver the advanced colorimetric tool', 1, '', '619162837.mp4', 'If the primary corrections are characterized by affecting an entire image, the secondary corrections a', 1, 3, 1, 0, '2021-04-23 07:27:16', '2021-04-23 07:27:16'),
(5, 'ver the advanced colorimetric tool 3', 1, '', '619162837.mp4', 'If the primary corrections are characterized by affecting an entire image, the secondary corrections a 3', 2, 3, 2, 1, '2021-04-23 07:27:16', '2021-04-23 07:27:16'),
(6, 'Primary Corrections 1 ', 1, '', '619162526.mp4', 'n  1 the second course of this Domestika Basics you will make your first color corrections, commonly called primary corrections, which refer to all those tweaks that affect the entire image of a plane and that are used to achieve homogeneity in the ...', 2, 1, 1, 0, '2021-04-23 07:22:05', '2021-04-23 07:22:05'),
(7, 'DaVinci Resolve: Edit 2', 2, '', '619957812.mp4', 'She\'s currently working as a freelance, although she spent 4 years in the studio El Colorado, where she worked on color grading for film and television projects such as Villaviciosa de al lado, Morir, El cuaderno de Sara, and Pulsaciones. She\'s also worked on documentaries, shows like Wild Frank, shorts films like Piscina, and numerous advertising campaigns.', 1, 7, 1, 1, '2021-05-02 12:16:51', '2021-05-02 12:16:51');

-- --------------------------------------------------------

--
-- Table structure for table `video_completeds`
--

CREATE TABLE `video_completeds` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `theme_id` int(11) NOT NULL,
  `video_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `video_completeds`
--

INSERT INTO `video_completeds` (`id`, `theme_id`, `video_id`, `user_id`, `created_at`, `updated_at`) VALUES
(5, 4, 0, 1, '2021-04-26 11:51:26', '2021-04-26 11:51:26'),
(6, 1, 6, 1, '2021-04-26 11:56:35', '2021-04-26 11:56:35'),
(7, 1, 1, 1, '2021-04-26 11:56:53', '2021-04-26 11:56:53'),
(8, 7, 0, 1, '2021-05-02 12:51:00', '2021-05-02 12:51:00'),
(9, 4, 0, 3, '2021-07-18 23:22:30', '2021-07-18 23:22:30'),
(10, 5, 0, 3, '2021-07-19 07:10:28', '2021-07-19 07:10:28'),
(11, 6, 0, 3, '2021-07-19 07:10:38', '2021-07-19 07:10:38'),
(12, 2, 2, 3, '2021-07-19 07:12:07', '2021-07-19 07:12:07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `carts_user_id_theme_id_index` (`user_id`,`theme_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `getmailpasswords`
--
ALTER TABLE `getmailpasswords`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `tests`
--
ALTER TABLE `tests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test_results`
--
ALTER TABLE `test_results`
  ADD PRIMARY KEY (`id`),
  ADD KEY `test_results_test_id_variant_id_status_user_id_index` (`test_id`,`variant_id`,`status`,`user_id`);

--
-- Indexes for table `themes`
--
ALTER TABLE `themes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `theme_user`
--
ALTER TABLE `theme_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `theme_user_theme_id_user_id_index` (`theme_id`,`user_id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `variants`
--
ALTER TABLE `variants`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `video_completeds`
--
ALTER TABLE `video_completeds`
  ADD PRIMARY KEY (`id`),
  ADD KEY `video_completeds_theme_id_video_id_user_id_index` (`theme_id`,`video_id`,`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `getmailpasswords`
--
ALTER TABLE `getmailpasswords`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tests`
--
ALTER TABLE `tests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `test_results`
--
ALTER TABLE `test_results`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `themes`
--
ALTER TABLE `themes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `theme_user`
--
ALTER TABLE `theme_user`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `variants`
--
ALTER TABLE `variants`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `video_completeds`
--
ALTER TABLE `video_completeds`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

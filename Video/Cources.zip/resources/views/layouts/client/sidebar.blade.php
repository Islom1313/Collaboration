<div class="sideBar fx fx-col" style="min-height: 100vh">
    <h5>Categories</h5>
    @if(count($categories)>0)
    @foreach ($categories as $category)
    <a href="{{ route('category',['id'=>$category->id]) }}">{{ $category->name }} ({{ count($category->themes) }})</a>            
    @endforeach
    @endif
</div>
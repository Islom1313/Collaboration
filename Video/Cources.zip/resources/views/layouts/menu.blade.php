@if(auth()->user()->role==1)
<li class="nav-item">
    <a href="{{ route('users.index') }}"
       class="nav-link {{ Request::is('users*') ? 'active' : '' }}">
        <p>Users</p>
    </a>
</li>
@endif
@if(auth()->user()->role==1)

<li class="nav-item">
    <a href="{{ route('categories.index') }}"
       class="nav-link {{ Request::is('categories*') ? 'active' : '' }}">
        <p>Categories</p>
    </a>
</li>

@endif
<li class="nav-item">
    <a href="{{ route('themes.index') }}"
       class="nav-link {{ Request::is('themes*') ? 'active' : '' }}">
        <p>Themes</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('allVideos.index') }}"
       class="nav-link {{ Request::is('allVideos*') ? 'active' : '' }}">
        <p>Videos</p>
    </a>
</li>










<li class="nav-item">
    <a href="{{ route('tests.index') }}"
       class="nav-link {{ Request::is('tests*') ? 'active' : '' }}">
        <p>Tests</p>
    </a>
</li>



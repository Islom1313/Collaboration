<nav>
    <div class="nav fx container vertical_center">
        <a href="{{ route('index') }}" class="nav__items  nav__logo fx-1 fx vertical_center">
            <img src="{{ asset('img/logo2.svg') }}" width="40">
            Cources
        </a>

        @if(!auth()->check())
        <div class="nav__items"><a href="{{ route('login') }}">Login</a></div>
        @else
        <div class="nav__items pr-1 ">
            <a href="{{ route('getCart') }}"><span>{{ auth()->user()->carts->count() }}</span><img src="{{ asset('img/cart.svg') }}" width="20"></a>
        </div>
      
        <div class="nav__items nav__auth fx vertical_center" onclick="document.querySelector('.nav__auth').classList.toggle('active')">
            <div class="auth__name pr-1">
                {{ auth()->user()->name }}
            </div>
            <div class="auth__avatar fx vertical_center">
                <img src="{{ asset('img/user.svg') }}" width="40" style="padding: 7px">▽
            </div>
            <div class="logout">
                <div> <a href="{{ route('home') }}">Profile</a></div>
                <form method="post" id="logout" action="{{ route('logout') }}">@csrf</form>
                <div onclick="document.getElementById('logout').submit()">Logout</div>
            </div>
        </div>
        @endif
        <div class="notification">
            <span>&#9650;</span>
            Please first <a href="{{ route('login') }}">login</a> 
        </div>
    </div>


</nav>
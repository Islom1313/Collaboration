<div class="col-md-6">
    @csrf
    <label for="name">Name</label>
    <input class="form-control" name="name" id="name">
</div>
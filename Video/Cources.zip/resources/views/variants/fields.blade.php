<div class="col-md-12">
    <label for="question">Question</label>
    @if(count($questions)>0)
        
    <select class="form-control" name="test_id" id="question">
        @foreach ($questions as $question)
        @if(request()->id == $question->id)

        <option selected value="{{ $question->id }}">{{ $question->question }}</option>

        @else

        <option value="{{ $question->id }}">{{ $question->question }}</option>

        @endif
        @endforeach
        
    </select> 
    @endif
</div>
<div class="col-md-10">
    <label for="answer">Answer</label>
    <input class="form-control" name="answer" type="text" value="{{ isset($variant)? $variant->answer : '' }}" id="answer"> 
</div>
<div class="col-md-2">
    <label for="status">Status</label>
    <input class="form-control" name="status" value="{{ isset($variant)? $variant->status : '0' }}" type="text" id="status"> 
</div>
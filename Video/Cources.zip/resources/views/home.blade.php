@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">

        <div class="table-responsive">
            @if (count($themes)>0)
            <table class="table" id="themes-table">
                <thead>
                    <tr>
                        <th>name</th>
                      
                        <th>img</th>
                        <th>category</th>
                       
                        <th colspan="3">Action</th>
                    </tr>
                </thead>
                <tbody>
                   
                        
                    
                @foreach($themes as $theme)
                    <tr>
                        <td>{{ $theme->name }}</td>
                       
                       
        
                        <td><img src="{{ asset('upload/videos/poster/'.$theme->img) }}" width="250"></td>
                        <td>{{ $theme->category->name }}</td>
                       
                        <td width="120">
                            <div class='btn-group'>
                                <a href="{{ route('lessons', [$theme->id]) }}" class='btn btn-default btn-xs'>
                                    <i class="far fa-eye"></i>
                                </a>
                               
                            </div>
                         
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
            @else
                You have not  videos yet, please buy       
            @endif
        </div>
        
    </div>
</div>
@endsection

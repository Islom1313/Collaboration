<div>
    Password:
</div>
<div >
   <span style="font-weight:bold;
        font-size:120%;">{{$pw}}</span>
</div>
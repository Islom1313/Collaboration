<div class="table-responsive">
    <table class="table" id="videos-table">
        <thead>
            <tr>
                <th>name</th>
                <th>video</th>
                <th>body</th>
                <th>order</th>
                <th>theme</th>
                <th>level</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        @foreach($videos as $video)
            <tr>
                <td>{{ $video->name }}</td>
                <td><video src="{{ asset('upload/videos/file/'.$video->path) }}" autoplay width="150"></video></td>
                <td>{{ $video->body }}</td>
                <td>{{ $video->order }}</td>
                <td>{{ $video->theme->name }}</td>
                <td>{{ $video->level }}</td>
               
                <td width="120">
                    {!! Form::open(['route' => ['allVideos.destroy', $video->id], 'method' => 'delete']) !!}
                    <div class='btn-group'>
                        <a href="{{ route('allVideos.show', [$video->id]) }}" class='btn btn-default btn-xs'>
                            <i class="far fa-eye"></i>
                        </a>
                        <a href="{{ route('allVideos.edit', [$video->id]) }}" class='btn btn-default btn-xs'>
                            <i class="far fa-edit"></i>
                        </a>
                        {!! Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]) !!}
                    </div>
                    {!! Form::close() !!}
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>

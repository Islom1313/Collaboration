 <div class="col-md-6">
     <label for="name">title</label>
     <input type="text" class="form-control" value="{{ isset($video)? $video->name : '' }}" id="name" name="name">
 </div>
 <div class="col-md-6">
    <label for="body">body</label>
    <input type="text" class="form-control" id="body" value="{{ isset($video)? $video->body : '' }}"  name="body">
</div>
<div class="col-md-6">
    <label for="order">order</label>
    <input type="number" class="form-control" value="{{ isset($video)? $video->order : '1' }}"  id="order" name="order">
</div>
<div class="col-md-6">
    <label for="theme">theme</label>
    @if(count($themes)>0)
    <select  class="form-control" id="theme" name="theme_id">
        @foreach ($themes as $theme)
            @if(isset($video) && $video->theme_id == $theme->id)
            <option selected value="{{ $theme->id }}">{{ $theme->name }}</option>
            @else
            <option value="{{ $theme->id }}">{{ $theme->name }}</option>

            @endif
        @endforeach
    </select>
    @else
        no theme created yet... <br> <a href="{{ route('themes.create') }}">Create Theme</a>
    @endif
</div>
<div class="col-md-6">
    <label for="level">level</label>
    <input type="number" class="form-control" id="level" value="1" name="level">
</div>
<div class="col-md-6">
    <label for="video">video</label>
    <input type="file" class="form-control" id="video" name="path">
</div>
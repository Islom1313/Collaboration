@extends('layouts.client.app')
@section('body')
  <div class="container fx">
    @include('layouts.client.sidebar')
    
    <div class="mainSide">
      <div class="mainSide__title">
        <h2>Cart</h2>
      </div>
      <div class="mainSide__videos fx">
        @if(count($carts)>0)
        <div class="table-responsive">
            <table class="table" id="users-table">
                <thead>
                    <tr>
                        <th >id</th>
                        <th >Poster</th>
                        <th >Name</th>
                        <th >Body</th>
                        <th style="width:65px;" >Price £</th>
                        {{-- <th >Balance</th> --}}
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                  
                @foreach($carts as $cart)
                @php
                    $theme = $cart->theme;

                @endphp
                @if($theme)    
                <tr class="cart_padding">
                        <td>{{ $cart->id }}</td>
                        <td><img src="{{ asset('upload/videos/poster/'.$theme->img) }}" width="150"></td>
                        <td>{{ $theme->name }}</td>
                        <td>{!! Str::words($theme->body, 25, '...') !!}</td>
                        <td class="text-center">{{ $theme->sale_price!=null ? $theme->sale_price : $theme->price }}</td>
                        <td width="120" style="text-align: center">
                            <a href="{{ route('Cartpayment',['id'=>$theme->id, 'cart'=>$cart->id]) }}" class="btn btn-primary"><img src="{{ asset('img/buy.svg') }}" width="15"></a>
                            {!! Form::open(['route' => ['carts.destroy', $cart->id], 'method' => 'delete']) !!}
 
                                {!! Form::button('<img src="/img/delete.svg" width="15">', ['type' => 'submit', 'class' => 'btn btn-danger', 'onclick' => "return confirm('Are you sure?')"]) !!}
                           
                            {!! Form::close() !!}
                        </td>
                        
                    </tr>@endif
                @endforeach
               
                </tbody>
            </table>
        </div>
        

        @else

            no cart exists 
        @endif
      </div>
    </div>
  </div>
  <div id="smart-button-container">
    <div style="text-align: center;">
      <div id="paypal-button-container"></div>
    </div>
  </div>
  
@endsection
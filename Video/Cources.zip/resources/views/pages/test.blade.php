@extends('layouts.client.app')
@section('body')
  <div class="container fx">
    @include('layouts.client.sidebar')
    
    <div class="mainSide">
        @if($theme)
        
        
        <div class="mainSide__title">
          <h2>{{ $theme->name }} - Test</h2>
          
        </div>
       
        <div class="mainSide__videos fx">
            <div class="lesson lesson_part1 fx-1">
                <div class="lesson__test ">
                    @if($countAnswers != $countQuestion || $countQuestion==0)
                    <form action="{{ route('testSubmit') }}" method="post">@csrf

                        @if(count($theme->questions)>0)
                            @foreach ($theme->questions as $k=>$question)
                                <h4>{{ ++$k }}. {{ $question->question }}</h4>
                                @if(count($question->variants)>0)
                                    @foreach ($question->variants as $variant)
                                    
                                    <input type="radio" id="q-{{ $variant->id }}" required name="q-{{ $question->id }}" value="{{ $variant->id}}">
                                    <label for="q-{{ $variant->id }}">{{ $variant->answer }}</label><br>
                                    
                                    @endforeach
                                @endif
                            @endforeach
                        @endif
                        <input type="submit" value="Test Submit" class="btn btn-secondary">
                    </form>
                    @else

                        <h3 >Test finished </h3>
                        <div>
                            <h4>Your score</h4>
                            <p><b>{{ $sum }}</b> out of <b>{{ $countQuestion }}</b> is correct, your score <b>{{ (int)($sum*100/$countQuestion) }}%</b> !</p> 
                            <div class="fx">
                                <form style="margin-right: 1rem" action="{{ route('resetTest') }}" method="post">
                                    @csrf
                                    <input type="hidden" name="theme_id" value="{{ $theme->id }}">
                                    <input type="submit" class="btn btn-danger"  value="reset">
                                </form>
                                <form action="{{ route('getSertificate') }}" method="post">
                                    @csrf
                                    <input type="hidden" name="theme_id" value="{{ $theme->id }}">
                                    <input type="hidden" value="{{ (int)($sum*100/$countQuestion) }}" name="score">
                                    <input type="submit" class="btn btn-primary"  value="get sertificate">
                                </form>

                            </div>
                        </div>
                    @endif
                </div>
                
            </div>
            <div class="lesson lesson_part2">
                <div class="lesson__lists">
                    @if (count($vids)>0)
                        @php
                            $count = 1;
                        @endphp
                        @foreach($vids as $vid)
                        <a href="{{ route('lessons',['id'=>$vid->theme_id, 'video_id'=>$vid->id]) }}" class="lesson__lists--each ">
                            <span>{{  $count }}.</span> {{ $vid->name }}<span class="done" style="color: blue">{!! $vid->access($vid->theme_id, $vid->id)? '&#10003;' : '' !!}</span>
                        </a>
                         @php
                             $count++;
                         @endphp
                        @endforeach
                    @endif
                </div>
            </div>
        </div>

         
        @endif
    </div>
  </div>
  
@endsection
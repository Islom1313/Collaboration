@extends('layouts.client.app')
@section('body')
  <div class="container fx">
    @include('layouts.client.sidebar')
    
    <div class="mainSide">
        @if($theme)
        
        
        <div class="mainSide__title">
          <h2>{{ $theme->name }}</h2>
          @if(!$theme->users->where('id',auth()->user()->id)->first())
           <a  id="myBtn"  style="background-color: #40637f; cursor: pointer;"> Get access </a>
         <a style="    left: -5px;"  href="{{ route('getCart',['id'=>$theme->id]) }}">Add to cart £ {{ $theme->sale_price!=null ? $theme->sale_price : $theme->price }}</a>@endif
        </div>
        <link href="https://vjs.zencdn.net/7.11.4/video-js.css" rel="stylesheet" />
        <link href="https://unpkg.com/@videojs/themes@1/dist/forest/index.css" 
        rel="stylesheet">
        <div class="mainSide__videos fx">
            <div class="lesson lesson_part1">
                <div class="lesson__video" >
                    <video   id="my-video" height="400" style="max-width: 600px" class="video-js vjs-theme-forest"
    controls     data-setup="{}"
  >@php
     
  @endphp
    <source  src="{{$video!=null? asset('upload/videos/file/'.$video->path) : '#'}}" type="video/mp4" />
    
        <p class="vjs-no-js">
        To view this video please enable JavaScript, and consider upgrading to a
        web browser that
        <a href="https://videojs.com/html5-video-support/" target="_blank"
            >supports HTML5 video</a
        >
        </p>
    </video>
    <script src="https://vjs.zencdn.net/7.11.4/video.min.js"></script>
                </div>
                <div class="lesson__info">
                    <h5>About this course</h5>
                    <p>{{ $theme->body }}</p>
                    <h5 >About this video</h5>
                    <h6>{{ $video? $video->name : '-' }}</h6>
                    <p>{!! $video? $video->body : '-' !!}</p>
                </div>
            </div>
            <div class="lesson lesson_part2">
                <div class="lesson__lists">
                    @php
                            $count = 1;
                        @endphp
                    @if (count($vids)>0)
                        
                        @foreach($vids as $vid)
                        <a href="{{ route('lessons',['id'=>$vid->theme_id, 'video_id'=>$vid->id]) }}" class="lesson__lists--each {{ $video!=null && $video->id==$vid->id? 'active' : ''  }}">
                            <span>{{  $count }}.</span> {{ $vid->name }}  <span class="done" style="color: blue">{!! $vid->access($vid->theme_id, $vid->id)? '&#10003;' : '' !!}</span>
                        </a>
                         @php
                             $count++;
                         @endphp
                        @endforeach
                    @endif
                    
                    <div class="lesson__lists">
                        <a href="{{$finished_video? route('test',['id'=>$vid->theme_id]) : '#' }}" class="lesson__lists--each {{ $video!=null && $video->id==$vid->id? 'active' : ''  }}">
                            <span>{{  $count }}.</span> TEST
                        </a>
                    </div>
                </div>
            </div>
        </div>

         
        @endif
    </div>
  </div>
  <input type="hidden" id="routess" value="{{ route('videoComplated') }}">
  <input type="hidden" id="theme_id" value="{{ $theme->id }}">
  <input type="hidden" id="video_id" value="{{$video? $video->id : '0' }}">
  <script>
     
     
       
      // Get the video element with id="myVideo"
        var vid =document.getElementById("my-video");
        var dur = 0
        window.onload = function() {
            
                vid.onplay = function() {
                    dur = vid.duration;
                    console.log(dur);
                };
         
          
            };
      
        // Assign an ontimeupdate event to the video element, and execute a function if the current playback position has changed
        vid.ontimeupdate = function() {myFunction()};
        let inside = true
        function myFunction() {
           
        // Display the current position of the video in a p element with id="demo"
        let  cur =  vid.currentTime;
        
        if(inside && cur>dur-3 ){
            postVideoSeen();
            inside = false;
        }
       
        }
        let metas = document.getElementsByTagName('meta');
      
        function postVideoSeen(){
            let theme_ids = document.getElementById('theme_id').value;
            let video_ids = document.getElementById('video_id').value;
            console.log(video_ids, theme_ids);
            let route = document.getElementById('routess');
                var data = {theme_id:theme_ids,video_id: video_ids};
                console.log('inside')
                 var xhttp = new XMLHttpRequest();
                xhttp.open("POST", '/videoComplated', true); 
                xhttp.setRequestHeader("X-CSRF-Token", metas[2].getAttribute("content"));
                xhttp.setRequestHeader("Content-Type", "application/json");
                xhttp.onreadystatechange = function() {
                        console.log('here');
                    if (this.readyState == 4 && this.status == 200) {
                       
                        var response = this.responseText;
                    }
                };
                xhttp.send(JSON.stringify(data));
        }
  </script>
  <style>
   
    /* The Modal (background) */
    .modal {
      display: none; /* Hidden by default */
      position: fixed; /* Stay in place */
      z-index: 1; /* Sit on top */
      padding-top: 100px; /* Location of the box */
      left: 0;
      top: 0;
      width: 100%; /* Full width */
      height: 100%; /* Full height */
      overflow: auto; /* Enable scroll if needed */
      background-color: rgb(0,0,0); /* Fallback color */
      background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
    }
    
    /* Modal Content */
    .modal-content {
      background-color: #fefefe;
      margin: auto;
      padding: 20px;
      border: 1px solid #888;
      max-width: 300px;
      text-align: center;
    }
    .modal-content input{
        padding: 5px 5px;

    }
    /* The Close Button */
    .close {
      color: #aaaaaa;
      float: right;
      font-size: 28px;
      font-weight: bold;
    }
    
    .close:hover,
    .close:focus {
      color: #000;
      text-decoration: none;
      cursor: pointer;
    }
    </style>
    <!-- The Modal -->
<div id="myModal" class="modal">

    <!-- Modal content -->
    <div class="modal-content">
      <span class="close">&times;</span>
      <form action="{{ route('enterKey') }}" method="post">
        @csrf 
        <input type="hidden" name="theme_id" value="{{ $theme->id }}">
        <input type="number " placeholder="Enter Key" name="password">
        <input type="submit" class="submitBtn" value="submit">
      </form>
    </div>
  
  </div>
  
  <script>
  // Get the modal
  var modal = document.getElementById("myModal");
  
  // Get the button that opens the modal
  var btn = document.getElementById("myBtn");
  
  // Get the <span> element that closes the modal
  var span = document.getElementsByClassName("close")[0];
  
  // When the user clicks the button, open the modal 
  btn.onclick = function() {
    modal.style.display = "block";
  }
  
  // When the user clicks on <span> (x), close the modal
  span.onclick = function() {
    modal.style.display = "none";
  }
  
  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    if (event.target == modal) {
      modal.style.display = "none";
    }
  }
  </script>
@endsection
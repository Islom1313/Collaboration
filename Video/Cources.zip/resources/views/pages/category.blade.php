@extends('layouts.client.app')
@section('body')
  <div class="container fx">
    @include('layouts.client.sidebar')
    <div class="mainSide">
      <a href="{{ route('register') }}" style="margin-bottom:1rem; display:block">
        <img src="{{ asset('img/banner.png') }}" style="width:100%">
      </a>
      <div class="mainSide__title">
        <h2>{{ $name? $name->name : '' }}</h2>
      </div>
     
      @if(count($themes)>0)
      
      
      <div class="mainSide__videos fx">
        @foreach ($themes as $theme)
        <div class="mainSide__videos-each" >
          <div  class="mainSide__videos__poster"  data-video="{{count($theme->videos)>0? route('index').'/upload/videos/file/'.$theme->videos[0]->path : '#'}}"  onclick="openModal(this)">
            <img  src="{{ asset('upload/videos/poster/'.$theme->img) }}">
            <img src="{{ asset('img/play.svg') }}" width="15" class="play_button">
          </div>
          <div class="mainSide__videos__title" @if (auth()->check()) data-url="{{ route('lessons',['id'=>$theme->id]) }}" onclick="openurl(this)"
            
            @endif>
            <p>@if($theme->prim) <span>BEST SELLER</span> @endif {{ $theme->name }}</p>
          </div>
          <div class="mainSide__videos__author"  @if (auth()->check()) data-url="{{ route('lessons',['id'=>$theme->id]) }}" onclick="openurl(this)"
            
            @endif>
            <p>A course by <i>{{ $theme->user->name }}</i></p>  
          </div>
          <div class="mainSide__videos__undertitle"  @if (auth()->check()) data-url="{{ route('lessons',['id'=>$theme->id]) }}" onclick="openurl(this)"
            
            @endif >
            <p>{{ $theme->undertitle }}</p>
              
          </div>
          <div class="mainSide__videos__statistic">
            <ul>
              <li><img src="{{ asset('img/group.svg') }}" width="15"> {{ rand(10000, 85000) }} </li>
              <li><img src="{{ asset('img/like.svg') }}" width="15"> {{ rand(45, 100)}}% </li>
            </ul>
          </div>
          <div class="mainSide__videos__week " data-video="{{count($theme->videos)>0? route('index').'/upload/videos/file/'.$theme->videos[0]->path : '#'}}" onclick="openModal(this)">
            <p class="fx vertical_center"><img style="margin-right: 0.5rem" src="{{ asset('img/preview.svg') }}" width="15">   Preview</p> 
          </div>
          <div class="mainSide__videos__discount">
            {{ $theme->sale }}% <span>${{ $theme->price }} USD</span>  
          </div>
          <div class="mainSide__videos__price" @if (auth()->check()) data-url="{{ route('index') }}" onclick="openCart(this,{{ $theme->id }})"
            
            @else onclick="shownotification()" @endif>
            <img src="{{ asset('img/cart.svg') }}" width="20"> ${{ number_format($theme->sale_price,2) }} USD
          </div>  
        </div>

        @endforeach
      </div>
      @endif
      
     
    </div>
  </div>
  <link href="https://vjs.zencdn.net/7.11.4/video-js.css" rel="stylesheet" />
  <link href="https://unpkg.com/@videojs/themes@1/dist/forest/index.css" 
rel="stylesheet">
  <div class="modal">
    <div class="modal__centent">
      <div class="modal__body">
        <div class="close" onclick="document.querySelector('.modal').style.display='none'">✕</div>
        <video
    id="my-video"
    class="video-js vjs-theme-forest"
    controls
    preload="auto"
    width="450"
    height="264"
   
    data-setup="{}"
  >
    <source id="modalVideoSource" src="{{ asset('upload/videos/file/619162548.mp4') }}" type="video/mp4" />
    
    <p class="vjs-no-js">
      To view this video please enable JavaScript, and consider upgrading to a
      web browser that
      <a href="https://videojs.com/html5-video-support/" target="_blank"
        >supports HTML5 video</a
      >
    </p>
  </video>
      </div>
    </div>
  </div>
  <script src="https://vjs.zencdn.net/7.11.4/video.min.js"></script>
  <script>
    
    function shownotification(){
      document.querySelector('.notification').classList.add('active');
      setTimeout(() => {
        document.querySelector('.notification').classList.remove('active')
      }, 2000);
    }
    function openurl(e){
      let url = e.getAttribute('data-url');
      // console.log(url);
      window.open(url);
    }
    function openCart(e,id){
      let url = e.getAttribute('data-url');
      // console.log(url);
      window.open(url+'/cart/?id='+id);
    }
    function openModal(e){
      let video = e.getAttribute('data-video');
      document.getElementById('modalVideoSource').src = video;
      document.querySelector('.modal').style.display='flex';
    }
  </script>
@endsection
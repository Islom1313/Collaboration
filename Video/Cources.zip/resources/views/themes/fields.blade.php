<div class="col-md-6">
    <label for="name">title</label>
    <input class="form-control" name="name" value="{{ isset($theme)? $theme->name : '' }}" type="text" id="name"> 
</div>
<div class="col-md-6">
    <label for="undertitle">undertitle</label>
    <input class="form-control" name="undertitle" value="{{ isset($theme)? $theme->undertitle : '' }}"  type="text" id="name"> 
</div>

<div class="col-md-6">
    <label for="body">body</label>
    <textarea class="form-control"  name="body"  id="body"> {{ isset($theme)? $theme->body : '' }}</textarea>
</div>
<div class="col-md-6">
    <label for="img">img</label>
    @if(isset($theme))
        <img src="{{ asset('upload/videos/poster/').'/'.$theme->img }}" width="150">
    @endif
    <input class="form-control" name="img" type="file" id="img"> 
</div>
<div class="col-md-6">
    <label for="category">category</label>
    @if(count($categories)>0)
    <select class="form-control" name="category_id"  id="category"> 
        @foreach ($categories as $category)
        <option value="{{ $category->id }}">{{ $category->name }}</option>
        @endforeach
    </select>
    @endif
    
       
    
</div>
<div class="col-md-6">
    <label for="price">price</label>
    <input class="form-control" name="price" value="{{ isset($theme)? $theme->price : '' }}" type="number" id="price" step="0.01"> 
</div>
<div class="col-md-6">
    <label for="sale">sale</label>
    <input class="form-control" name="sale" value="{{ isset($theme)? $theme->sale : '' }}" type="number" id="sale" step="0.01"> 
</div>
<div class="col-md-6">
    <label for="sale_price">Sale price</label>
    <input class="form-control" name="sale_price" value="{{ isset($theme)? $theme->sale_price : '' }}" type="number" id="sale_price" step="0.01">
</div>
<div class="table-responsive">
    <table class="table" id="themes-table">
        <thead>
            <tr>
                <th>name</th>
                <th>body</th>
                <th>img</th>
                <th>category</th>
                <th>price</th>
                <th>sale</th>
                <th>sale_price</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        @foreach($themes as $theme)
            <tr>
                <td>{{ $theme->name }}</td>
                <td>{{ $theme->undertitle }}</td>
                <td>{{ Str::words($theme->body, 10, '...') }}</td>

                <td><img src="{{ asset('upload/videos/poster/'.$theme->img) }}" width="250"></td>
                <td>{{ $theme->category->name }}</td>
                <td>{{ $theme->price }}</td>
                <td>{{ $theme->sale }}</td>
                <td>{{ $theme->sale_price }}</td>
                <td width="120">
                    {!! Form::open(['route' => ['themes.destroy', $theme->id], 'method' => 'delete']) !!}
                    <div class='btn-group'>
                        <a href="{{ route('themes.show', [$theme->id]) }}" class='btn btn-default btn-xs'>
                            <i class="far fa-eye"></i>
                        </a>
                        <a href="{{ route('themes.edit', [$theme->id]) }}" class='btn btn-default btn-xs'>
                            <i class="far fa-edit"></i>
                        </a>
                        {!! Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]) !!}
                    </div>
                    {!! Form::close() !!}
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>

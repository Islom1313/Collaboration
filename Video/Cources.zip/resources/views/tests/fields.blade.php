<div class="col-md-12">
    <label for="theme">Theme</label>
    @if(count($themes)>0)
        
    <select class="form-control" name="theme_id" type="text" id="theme">
        @foreach ($themes as $theme)
         @if (isset($test) && $test->theme_id == $theme->id)
         <option selected value="{{ $theme->id }}">{{ $theme->name }}</option>
         @else
         <option value="{{ $theme->id }}">{{ $theme->name }}</option>
             
         @endif
        @endforeach
        
    </select> 
    @endif
</div>
<div class="col-md-10">
    <label for="question">Question</label>
    <input class="form-control" name="question" value="{{ isset($test)? $test->question : '' }}" type="text" id="question"> 
</div>
<div class="col-md-2">
    <label for="orders">Order</label>
    <input class="form-control" name="orders" value="{{ isset($test)? $test->orders : '1' }}" type="number" id="orders"> 
</div>

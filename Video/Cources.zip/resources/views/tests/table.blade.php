<div class="table-responsive">
    <table class="table" id="tests-table">
        <thead>
            <tr>
                <th>Theme</th>
                <th>Question</th>
                <th>Order</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        @foreach($tests as $test)
            <tr>
                <td>{{ $test->theme->name }}</td>
                <td><b>{{ $test->question }}</b>
                    @if (count($test->variants)>0)
                    @php
                        $count = 1;
                    @endphp
                        @foreach ($test->variants as $variant)
                        <div class="row">

                            <p class="col-6">{{$count .' '. $variant->answer }}</p>
                            {!! Form::open(['route' => ['variants.destroy', $variant->id], 'method' => 'delete']) !!}
                            <div class='btn-group'>
                                
                                <a href="{{ route('variants.edit', [$variant->id]) }}/?id={{ $test->id }}" class='btn btn-default btn-xs'>
                                    <i class="far fa-edit"></i>
                                </a>
                                {!! Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]) !!}
                            </div>
                            {!! Form::close() !!}
                        </div>
                        @php
                            $count++;
                        @endphp
                        @endforeach
                        
                   
                        
                    @endif
                    <a class="btn btn-primary float-right"
                       href="{{ route('variants.create') }}/?id={{ $test->id }}">
                        Add answers
                    </a>
                   
                
                
                </td>
                <td>{{ $test->orders }}</td>
                <td width="120">
                    {!! Form::open(['route' => ['tests.destroy', $test->id], 'method' => 'delete']) !!}
                    <div class='btn-group'>
                        <a href="{{ route('tests.show', [$test->id]) }}" class='btn btn-default btn-xs'>
                            <i class="far fa-eye"></i>
                        </a>
                        <a href="{{ route('tests.edit', [$test->id]) }}" class='btn btn-default btn-xs'>
                            <i class="far fa-edit"></i>
                        </a>
                        {!! Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]) !!}
                    </div>
                    {!! Form::close() !!}
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
